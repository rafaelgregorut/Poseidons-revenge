/*! \file botao.h
 * \brief Interface de botao.c com a definição do tipo bot */

/*! \brief Tipo que representa um botão no jogo */
typedef struct botao *bot;
/*! \brief Estrutura para representar um botão no jogo */
struct botao{
  /*! \brief Retangulo com a area de atuacao do botao */
  SDL_Rect caixa;
  /*! \brief Indica qual a imagem atual do botao */
  int indiceBotaoAtual;
  /*! \brief Indica qual a imagem que estava no botao anteriormente, necessario para o vetor de botoes dos upgrades. Com os dois indices podemos aplicar o efeito de clique */
  int indiceBotaoAnterior;
};

bot Botao(int x, int y, int w, int h, int indice);

void liberaBotao(bot libera);

void carregaBotaoJogar(SDL_Surface **vetorBotaoJogar);

void carregaBotaoProximo(SDL_Surface **vetorBotaoProximo);

void carregaBotoesUps(SDL_Surface **vetorBotoesUps);

void carregaBotaoPular(SDL_Surface **vetorBotaoPular);

void carregaBotaoCreditos(SDL_Surface **vetorBotaoCreditos);

void carregaBotaoInstrucoes(SDL_Surface **vetorBotaoInstrucoes);

void carregaBotaoComecar(SDL_Surface **vetorBotaoComecar);

void carregaBotaoInicial(SDL_Surface **vetorBotaoInicial);

void carregaBotaoSom(SDL_Surface **vetorBotaoSom);

void carregaBotaoAnterior(SDL_Surface **vetorBotaoAnterior);

int handle_events(bot botao, SDL_Event evento);
