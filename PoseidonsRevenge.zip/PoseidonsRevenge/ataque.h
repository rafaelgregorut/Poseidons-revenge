#include "monstro.h"
/*! \file ataque.h 
 * \brief Interface de ataque.c com a definição do tipo ataque */  

/*! \brief Tipo que representa um ataque, seja ele lançado pelo jogador ou por algum monstro.*/
typedef struct celula *ataque;
/*! \brief Estrutura do tipo ataque usada para fazer uma lista ligada de ataques */
struct celula{
  /*! \brief Coordenada x inicial do ataque lancado */
  int initX;
  /*! \brief Coordenada y inicial do ataque lancado */
  int initY;
  /*! \brief A distancia maxima que um ataque pode percorrer */
  int distanciaMaxima;
  /*! \brief O dano que este ataque causa */
  int dano;
  /*! \brief Objeto do tipo Dot que sera usado para a movimentacao do ataque e para colisao do mesmo */
  Dot objAtaque;
  /*! \brief Ponteiro para o proximo ataque de uma lista ligada de ataques */
  ataque next;
  /*! \brief Ponteiro para a ultima celula da lista ligada de ataques. Agiliza a insercao de uma nova celula na lista */
  ataque ultimo;
};

ataque initListaAtaque();

void novoAtaque(Dot barco, ataque cabeca, int width, int height, int velocidade, int distanciaMaxima, int dano);

void liberaAtaque(ataque libera);

void carregaVetorImagensFlecha(SDL_Surface **flecha);

int contaFlechas(ataque cabecaFlechas);

void carregaVetorImagensBolaDeFogo(SDL_Surface **bolaDeFogo);

void carregaVetorImagensFlechaFogo(SDL_Surface **flechaFogo);

void carregaVetorImagensRaio(SDL_Surface **raio);

void carregaVetorImagensAguia(SDL_Surface **aguia);

void moveAtaqueUnico(ataque cabeca, monstro cabecaMonstro, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT);

void moveAtaqueArea(ataque cabeca, monstro cabecaMonstro, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT);
