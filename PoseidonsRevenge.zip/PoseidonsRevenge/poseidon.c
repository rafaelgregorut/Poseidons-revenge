/*! \file poseidon.c 
 * \brief Arquivo com a função main do jogo em com as transições de fases */
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "SDL/SDL_mixer.h"
#include "botao.h"
#include "timer.h"
#include "image.h"
#include "barco.h"
#include "music.h"
#include "entradaString.h"
#include "ranking.h"

/*! \brief Largura da tela de jogo */
const int SCREEN_WIDTH = 860;
/*! \brief Altura da tela de jogo */ 
const int SCREEN_HEIGHT = 560;
const int SCREEN_BPP = 32;
/*! \brief Altura da barra de vida, magia, energia na parte inferior da tela */
const int ALTURA_BARRA_INFERIOR = 60;
/*! \brief Taxa de frames por segundo */
const int FRAMES_PER_SECOND = 20;

/*! \brief Vetor de imagens do barco principal */
SDL_Surface *barcoJogador[16];
/*! \brief Vetor de imagens da barra de vida do jogador */
SDL_Surface *barraVida[41];
/*! \brief Superfície onde será escrido "Vida" em cima da barra de vida */
SDL_Surface *nomeVida = NULL;
/*! \brief Vetor de imagens da barra de vida dos inimigos */
SDL_Surface *barraVidaInimigo[41];
/*! \brief Vetor de imagens da barra de magia do jogador */
SDL_Surface *barraMagia[41];
/*! \brief Superfície onde será escrido "Magia" em cima da barra de magia */
SDL_Surface *nomeMagia = NULL;
/*! \brief Vetor de imagens da barra de energia do jogador */
SDL_Surface *barraEnergia[41];
/*! \brief Superfície onde será escrido "Energia" em cima da barra de energia */
SDL_Surface *nomeEnergia = NULL;
/*! \brief Vetor de imagens da flecha padrão */
SDL_Surface *vetorFlecha[16];
/*! \brief Vetor de imagens da bola de fogo */
SDL_Surface *vetorBolaDeFogo[1];
/*! \brief Vetor de imagens da flecha de fogo */
SDL_Surface *vetorFlechaFogo[16];
/*! \brief Vetor de imagens do raio*/
SDL_Surface *vetorRaio[8];
/*! \brief Vetor de imagens da águia */
SDL_Surface *vetorAguia[16];
/*! \brief Vetor de imagens do kraken */
SDL_Surface *vetorKraken[1];
/*! \brief Vetor de imagens do ataque lançado pelo kraken */
SDL_Surface *vetorAtaqueKraken[1];
/*! \brief Vetor de imagens da serpente */
SDL_Surface *vetorSerpente[2];
/*! \brief Vetor de imagens da harpia */
SDL_Surface *vetorHarpia[2];
/*! \brief Vetor de imagens do barco inimigo */
SDL_Surface *vetorBarcoInimigo[4];
/*! \brief Vetor de imagens da sereia */
SDL_Surface *vetorSereia[1];
/*! \brief Vetor de imagens do tornado */
SDL_Surface *vetorTornado[1];
/*! \brief Vetor de iamgens da catapulta */
SDL_Surface *vetorCatapulta[1];
/*! \brief Vetor de imagens da pedra */
SDL_Surface *vetorPedra[1];
/*! \brief Vetor de imagens da ilha da catapulta */
SDL_Surface *vetorIlhaCatapulta[1];

/*! \brief Tela de menu inicial */
SDL_Surface *menu = NULL;
/*! \brief Imagem de fundo */
SDL_Surface *background = NULL;
/*! \brief Tela de jogo */
SDL_Surface *screen = NULL;
/*! \brief Primeira tela de enredo */
SDL_Surface *tela1 = NULL;
/*! \brief Segunda tela de enredo */
SDL_Surface *tela2 = NULL;
/*! \brief Terceira tela de enredo */
SDL_Surface *tela3 = NULL;
/*! \brief Tela final */
SDL_Surface *youWin = NULL;
/*! \brief Tela de game over */
SDL_Surface *gameOver = NULL;
/*! \brief Tela de upgrades */
SDL_Surface *upgrades = NULL;
/*! \brief Superfície onde serão aplicadas mensagens durante o jogo */
SDL_Surface *message = NULL;
/*! \brief Pontuação */
SDL_Surface *points = NULL;
/*! \brief Vetor de imagens do botão jogar */
SDL_Surface *vetorBotaoJogar[2];
/*! \brief Vetor de imagens dos botões de upgrades */
SDL_Surface *vetorBotaoProximo[2];
/*! \brief Vetor com as imagens dos botões dos ups */
SDL_Surface *vetorBotoesUps[12];
/*! \brief Vetor com as imagens do botão pular */
SDL_Surface *vetorBotaoPular[2];
/*! \brief Vetor com as imagens do botão de créditos */
SDL_Surface *vetorBotaoCreditos[2];
/*! \brief Vetor com as imagens do botão de instruções */
SDL_Surface *vetorBotaoInstrucoes[2];
/*! \brief Vetor com as imagens do botão começar */
SDL_Surface *vetorBotaoComecar[2];
/*! \brief Vetor com as iamgens do botão para votar à tela inicial */
SDL_Surface *vetorBotaoInicial[2];
/*! \brief Vetor com as imagens do botão de opção de som */
SDL_Surface *vetorBotaoSom[2];
/*! \brief Vetor com as imagens do botão anterior */
SDL_Surface *vetorBotaoAnterior[2];

/*! \brief Fonte usada para escrever a pontuação */
TTF_Font *font = NULL;

/*! \brief Cor da fonte */
SDL_Color textColor = {255, 255, 255};

/*! \brief Objeto que representa a ilha das catapultas das duas primeiras fases */
Dot ilhaCatapulta = NULL;

/*! \brief Vetor de músicas do jogo */
Mix_Music *music[5];

/*! \brief Botão de compra do up águia */
bot upAguia = NULL;
/*! \brief Botão de compra do up de flechas de fogo */
bot upFlechaFogo = NULL;
/*! \brief Botão de compra do up de bolsa de ventos */
bot upBolsaVentos = NULL;
/*! \brief Botão de compra do up de vida extra */
bot vidaUp = NULL;
/*! \brief Botão de compra do up de magia extra */
bot upMagia = NULL;
/*! \brief Botão de compra do up de energia extra */
bot upEnergia = NULL;

/*! \brief Botão próxima tela. Usado nas telas de enredo, instruções e upgrades */
bot botaoProximo = NULL;
/*! \brief Botão de iniciar o jogo. Usado na tela de menu e de instruções */
bot botaoJogar = NULL;
/*! \brief Botão de pular uma sequência de telas. Usado nas telas de enredo */
bot botaoPular = NULL;
/*! \brief Botão para retornar à tela de créditos. Usado na tela de menu */
bot botaoCreditos = NULL;
/*! \brief Botão para a tela de instruções. Usado na tela de menu */
bot botaoInstrucoes = NULL;
/*! \brief Botão de iniciar o jogo. Usado na última tela de enredo */
bot botaoComecar = NULL;
/*! \brief Botão que volta para a tela inicial. Usado nas telas de créditos e de instruções */
bot botaoInicial = NULL;
/*! \brief Botão que tira ou permite o uso do som do jogo. Usado na tela de menu */
bot botaoSom = NULL;
/*! \brief Botão que volta para a tela anterior. Usado nas telas de enredo e na última tela de instrução */
bot botaoAnterior = NULL;

/*! \brief Imagem da tela de instruções */
SDL_Surface *instrucoes1 = NULL, *instrucoes2 = NULL;
/*! \brief Imagem da tela de créditos */
SDL_Surface *creditos = NULL;
/*! \brief Tela para digitar o nome */
SDL_Surface *telaEntradaNome = NULL;
/*! \brief Nome do usuário */
nom entradaNome = NULL;
/*! \brief Porto de chegada */
Dot porto = NULL;
/*! \brief Imagem do porto de chegada */
SDL_Surface *imagemPorto = NULL;

/*! \brief Lista de flechas padrão lançadas pelo jogador */
ataque cabecaFlecha = NULL;
/*! \brief Lista de bolas de fogo lançadas pelo jogador */
ataque cabecaBolaDeFogo = NULL;
/*! \brief Lista de flechas de fogo lançadas pelo jogador */
ataque cabecaFlechaFogo = NULL;
/*! \brief Lista de raio lançados pelo jogador */
ataque cabecaRaio = NULL;
/*! \brief Lista de aguias lançadas pelo jogador */
ataque cabecaAguia = NULL;
/*! \brief Lista de catapultas do jogo */
ataque cabecaCatapulta = NULL;

/*! \brief Primeira sereia da fase 2 */
monstro sereia1 = NULL;
/*! \brief Segunda sereia da fase 2 */
monstro sereia2 = NULL;
/*! \brief Primeiro tornado da fase 4 */
monstro tornado1 = NULL;
/*! \brief Segundo tornado da fase 4 */
monstro tornado2 = NULL;
/*! \brief Terceiro tornado da fase 4 */
monstro tornado3 = NULL;
/*! \brief Ilha de catapultas da fase 1 */
Dot ilhaCatapulta1 = NULL;
/*! \brief Ilha de catapultas da fase 2 */
Dot ilhaCatapulta2 = NULL;
/*! \brief Ilha de catapultas da fase 3, ou seja, vai valer NULL */
Dot ilhaCatapulta3 = NULL;
/*! \brief Ilha de catapultas da fase 4, ou seja, vai valer NULL */
Dot ilhaCatapulta4 = NULL;

/*! \brief Lista de monstros da fase 1 */
monstro cabecaMonstro1 = NULL, apontaMonstro1 = NULL;
/*! \brief Lista de monstros da fase 2 */
monstro cabecaMonstro2 = NULL, apontaMonstro2 = NULL;
/*! \brief Lista de monstros da fase 3*/
monstro cabecaMonstro3 = NULL, apontaMonstro3 = NULL;
/*! \brief Lista de monstros da fase 4*/
monstro cabecaMonstro4 = NULL, apontaMonstro4 = NULL;

/*! \brief Os eventos de mouse e teclado que ocorrem no jogo */
SDL_Event event;

/*! \brief Vale 1 se o usuário digitou o nome, 0 caso contrário */
int entrouNome = FALSE;
/*! \breif Vale 1 se o usuário quiser música no jogo, 0 caso contrário */
int comSom = TRUE;
/*! \brief Superficie com a mensagem que aparece na tela de upgrades */
SDL_Surface *mensagemUp = NULL;

SDL_Surface *posicaoRanking[10], *nomesRanking[10], *pontuacaoRanking[10];
/*! \brief Vetor com as imagens do botão ranking */
SDL_Surface *vetorBotaoRanking[2];
/*! \brief Mensagem de parabéns quando um jogador estabelece um novo recorde */
SDL_Surface *novoRanking;
/*! \brief Imagem da tela de ranking */
SDL_Surface *telaRanking;
/*! \brief Botão que encaminha para a tela de ranking */
bot botaoRanking;
/*! \brief Vale 1 se ocorreu um novo recorde, 0 caso contrário */
int bateuRanking = FALSE;

/*! \brief Calcula o valor que deve usado em cada barra para apilcar a imagem correta da barra
 * \param valorAtual Valor atual representado pelo barra
 * \param valorTotal O máximo que a barra pode representar
 * \return O novo valor a ser representado pela barra */
int valorBarra(int valorAtual, int valorTotal)
{
  if(valorAtual > valorTotal)
    return 0;
  else if(valorAtual <= 0)
  	return 40;
  return -40 * (valorAtual - valorTotal) / valorTotal;
}

/*! \brief Inicializa todos os componentes do jogo 
 * \return 1 caso não ocorra nenhum erro, 0 caso contrário */
int init()
{
  /*Inicializa a SDL*/
  if(SDL_Init( SDL_INIT_EVERYTHING ) == -1)
    return FALSE;
  /*Configura a tela */
  screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_SWSURFACE);
  if(screen == NULL)
    return FALSE;
  if( TTF_Init() == -1 )
    return FALSE;
  SDL_WM_SetCaption("Poseidon's Revenge", NULL);
  /*inicializa a lista de flechas*/
  cabecaFlecha = initListaAtaque();
  /*inicializa a lista de bolas de fogo*/
  cabecaBolaDeFogo = initListaAtaque();
  /*inicializa a lista de flecha de fogo*/
  cabecaFlechaFogo = initListaAtaque();
  /*inicializa a lista de raio*/
  cabecaRaio = initListaAtaque();
  /*inicializa a lista de raio*/
  cabecaAguia = initListaAtaque();
    
  /*monstros da fase 1*/
  cabecaMonstro1 = malloc(sizeof *cabecaMonstro1);
  cabecaMonstro1->next = NULL;
  apontaMonstro1 = cabecaMonstro1;
  apontaMonstro1 = (apontaMonstro1->next = initMonstro(BARCOINIMIGO, 530, 380, 110, 110, 150, 0.0, 3));
  apontaMonstro1->objMonstro->indiceVetor = 3;
  apontaMonstro1 = (apontaMonstro1->next = initMonstro(CATAPULTA, 210, 10, 54, 70, 400, 0.0, 0));
  apontaMonstro1 = (apontaMonstro1->next = initMonstro(CATAPULTA, 320, 10, 54, 70, 400, 0.0, 0));
  ilhaCatapulta1 = initIlhaCatapulta(100, 0, 400, 180, 300, 0, 150);
  
  /*Monstros da fase 2*/
  cabecaMonstro2 = malloc(sizeof *cabecaMonstro2);
  cabecaMonstro2->next = NULL;
  apontaMonstro2 = cabecaMonstro2;
  apontaMonstro2 = (apontaMonstro2->next = initMonstro(CATAPULTA, 210, 10, 54, 70, 400, 0.0, 0));
  apontaMonstro2 = (apontaMonstro2->next = initMonstro(CATAPULTA, 320, 10, 54, 70, 400, 0.0, 0));
  ilhaCatapulta2 = initIlhaCatapulta(100, 0, 400, 180, 300, 0, 150);
  sereia1 = apontaMonstro2 = (apontaMonstro2->next = initMonstro(SEREIA, 550, 100, 80, 90, 1000000,0.0, 0));
  sereia2 = apontaMonstro2 = (apontaMonstro2->next = initMonstro(SEREIA, 150, 300, 80, 90, 1000000,0.0, 0));
  
  /*monstros da fase 3*/
  cabecaMonstro3 = malloc(sizeof *cabecaMonstro3);
  cabecaMonstro3->next = NULL;
  apontaMonstro3 = cabecaMonstro3;
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(BARCOINIMIGO, 700, 340, 110, 110, 150, 0.0, 2));
  apontaMonstro3->objMonstro->indiceVetor = 2;
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(SERPENTE, 100, 280, 150, 114, 250, 0.0, 1));
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(SERPENTE, 200, 0, 150, 114, 250, 0.0, -1));
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(HARPIA, 600, 300, 45, 45, 100, 0.0, rand() % 4));
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(HARPIA, 650, 300, 45, 45, 100, 0.0, rand() % 4));
  apontaMonstro3 = (apontaMonstro3->next = initMonstro(HARPIA, 700, 350, 45, 45, 100, 0.0, rand() % 4));
  ilhaCatapulta3 = NULL;
  
  /*monstros da fase 4*/
  cabecaMonstro4 = malloc(sizeof *cabecaMonstro4);
  cabecaMonstro4->next = NULL;
  apontaMonstro4 = cabecaMonstro4;
  apontaMonstro4 = (apontaMonstro4->next = initMonstro(KRAKEN, 500, 280, 250, 179, 500, 0.0, 1));
  apontaMonstro4 = (apontaMonstro4->next = initMonstro(BARCOINIMIGO, 392, 390, 110, 110, 150, 135*3.141592654/180, 0));
  tornado1 = apontaMonstro4 = (apontaMonstro4->next = initMonstro(TORNADO, 250, 100, 80, 90, 1000000,0.0,0));
  tornado2 = apontaMonstro4 = (apontaMonstro4->next = initMonstro(TORNADO, 400, 250, 80, 90, 1000000,0.0,0));
  tornado3 = apontaMonstro4 = (apontaMonstro4->next = initMonstro(TORNADO, 90, 350, 80, 90, 1000000,0.0,0));
  apontaMonstro4 = (apontaMonstro4->next = initMonstro(HARPIA, 600, 300, 45, 45, 100, 0.0, rand() % 4));
  apontaMonstro4 = (apontaMonstro4->next = initMonstro(HARPIA, 650, 300, 45, 45, 100, 0.0, rand() % 4));
  apontaMonstro4 = (apontaMonstro4->next = initMonstro(HARPIA, 700, 350, 45, 45, 100, 0.0, rand() % 4));
  ilhaCatapulta4 = NULL;
  
  /*Inicializa a ilha das catapultas*/
  ilhaCatapulta = initDot(100, 0, 400, 188, 0, TRUE, 0.0);
  ilhaCatapulta->circulo->circuloY = ilhaCatapulta->y;
  ilhaCatapulta->circulo->raio = 150;
  
  /*Inicializa os itens para coletar em cada fase */
  initBolas();
  
  porto = initDot(SCREEN_WIDTH - 70, SCREEN_HEIGHT/2 - 100,30,200,0,TRUE,0.0);
  /*Se tudo foi inicializado corretamente */
  return TRUE;
}

/*! \brief Carrega todas as imagens do jogo
 * \return 1 caso tudo seja carregado corretamente, 0 caso contrário */
int load_files()
{
  int i;
  menu = load_image("imagens/telas/menu.png");
  instrucoes1 = load_image("imagens/telas/instrucoes1.png");
  instrucoes2 = load_image("imagens/telas/instrucoes2.png");
  creditos = load_image("imagens/telas/creditos.png");
  background = load_image ("imagens/cenario/fundo.png");
  font = TTF_OpenFont("fonte/grec.ttf", 22);
  tela1 = load_image("imagens/enredo/tela1.png");
  tela2 = load_image("imagens/enredo/tela2.png");
  tela3 = load_image("imagens/enredo/tela3.png");
  youWin = load_image("imagens/telas/youWin.png");
  gameOver = load_image("imagens/telas/gameOver.png");
  upgrades = load_image("imagens/telas/upgrades.png");
  imagemPorto = load_image("imagens/cenario/porto.png");
  carregaVetorImagensBarcoJogador(barcoJogador);
  carregaBarraVida(barraVida);
  nomeVida = TTF_RenderText_Solid(font, "Vida", textColor);
  carregaBarraVidaInimigo(barraVidaInimigo);
  carregaBarraMagia(barraMagia);
  nomeMagia = TTF_RenderText_Solid(font, "Magia", textColor);
  carregaBarraEnergia(barraEnergia);
  nomeEnergia = TTF_RenderText_Solid(font, "Energia", textColor);
  carregaVetorImagensFlecha(vetorFlecha);
  carregaVetorImagensBolaDeFogo(vetorBolaDeFogo);
  carregaVetorImagensFlechaFogo(vetorFlechaFogo);
  carregaVetorImagensRaio(vetorRaio);
  carregaVetorImagensAguia(vetorAguia);
  carregaVetorImagensKraken(vetorKraken,vetorAtaqueKraken);
  carregaVetorImagensSerpente(vetorSerpente);
  carregaVetorImagensHarpia(vetorHarpia);
  carregaVetorImagensBarcoInimigo(vetorBarcoInimigo);
  carregaVetorImagensTornado(vetorTornado);
  initCatapulta(vetorCatapulta,vetorPedra, vetorIlhaCatapulta);
  initSereia(vetorSereia);
  carregaBotaoJogar(vetorBotaoJogar);
  carregaBotaoProximo(vetorBotaoProximo);
  carregaBotaoPular(vetorBotaoPular);
  carregaBotaoComecar(vetorBotaoComecar);
  carregaBotoesUps(vetorBotoesUps);
  carregaBotaoInicial(vetorBotaoInicial);
  carregaBotaoCreditos(vetorBotaoCreditos);
  carregaBotaoInstrucoes(vetorBotaoInstrucoes);
  carregaBotaoInicial(vetorBotaoInicial);
  carregaBotaoSom(vetorBotaoSom);
  carregaBotaoAnterior(vetorBotaoAnterior);
  carregaBotaoRanking(vetorBotaoRanking);
  i = carregaVetorMusica(music);
  if(i != 0)
    return FALSE;
  for(i = 0; i < 41; i++){
    if(barraVida[i] == NULL)
      return FALSE;
    if(barraVidaInimigo[i] == NULL)
      return FALSE;
    if(barraMagia[i] == NULL)
      return FALSE;
    if(barraEnergia[i] == NULL)
      return FALSE;
  }
  for(i = 0; i < 16; i++){
    if(barcoJogador[i] == NULL)
      return FALSE;
    if(vetorFlecha[i] == NULL)
      return FALSE;
    if(vetorFlechaFogo[i] == NULL)
      return FALSE;
    if(vetorAguia[i] == NULL)
      return FALSE;
  }
  for(i = 0; i < 12; i++)
    if(vetorBotoesUps[i] == NULL)
      return FALSE;
  for(i = 0; i < 8; i++)
    if(vetorRaio[i] == NULL)
      return FALSE;
  for(i = 0; i < 2; i++){
    if(vetorSerpente[i] == NULL)
      return FALSE;
    if(vetorHarpia[i] == NULL)
      return FALSE;
    if(vetorBarcoInimigo[i] == NULL)
      return FALSE;
    if(vetorBotaoPular[i] == NULL)
      return FALSE;  	
    if(vetorBotaoCreditos[i] == NULL)
      return FALSE;  	
    if(vetorBotaoInstrucoes[i] == NULL)
      return FALSE;  	
    if(vetorBotaoComecar[i] == NULL)
      return FALSE;
    if(vetorBotaoInicial[i] == NULL)
      return FALSE;
    if(vetorBotaoSom[i] == NULL)
      return FALSE;
    if(vetorBotaoAnterior[i] == NULL)
      return FALSE;
    if(vetorBotaoJogar[i] == NULL)
      return FALSE;
    if(vetorBotaoProximo[i] == NULL)
      return FALSE;  	
    if(vetorBotaoRanking[i] == NULL)
      return FALSE;  	
  }
  for(i = 0; i < 1; i++){
    if(vetorKraken[i] == NULL)
      return FALSE;
    if(vetorAtaqueKraken[i] == NULL)
      return FALSE;  	  	
    if(vetorSereia[i] == NULL)
      return FALSE;
    if(vetorTornado[i] == NULL)
      return FALSE;
    if(vetorCatapulta[i] == NULL)
      return FALSE;
    if(vetorPedra[i] == NULL)
      return FALSE;  
    if(vetorBolaDeFogo[i] == NULL)
      return FALSE;
    if(vetorIlhaCatapulta[i] == NULL)
      return FALSE;  
  }
  if(menu == NULL || background == NULL || screen == NULL)
    return FALSE;
  if(tela1 == NULL || tela2 == NULL || tela3 == NULL)
    return FALSE;
  if(youWin == NULL || gameOver == NULL)
    return FALSE;
  if(upgrades == NULL)
    return FALSE;
  if(instrucoes1 == NULL || instrucoes2 == NULL)
    return FALSE;
  if(creditos == NULL)
    return FALSE;
  if(imagemPorto == NULL)
    return FALSE;
  /*Se tudo foi carregado corretamente*/
  return TRUE;
}

/*! \brief Devolve a lista de monstros da fase atual do jogo
 * \param faseAtual A fase atual do jogo
 * \return A lista ligada de monstros da fase atual */
monstro listaMonstrosAtual(int faseAtual)
{
  if(faseAtual == FASE_1){
    return cabecaMonstro1;
  }
  else if(faseAtual == FASE_2){
    return cabecaMonstro2;
  }
  else if(faseAtual == FASE_3){
    return cabecaMonstro3;
  }
  else if(faseAtual == FASE_4){
    return cabecaMonstro4;
  }
  else
    return NULL;
}

/*! \brief Devolve a ilha de catapultas da fase atual
 * \param faseAtual A fase atual do jogo 
 * \return A ilha da catapultas na fase atual */
Dot listaIlhaCatapultaAtual(int faseAtual)
{
  if(faseAtual == FASE_1)
    return ilhaCatapulta1;
  else if(faseAtual == FASE_2)
    return ilhaCatapulta2;
  else if(faseAtual == FASE_3)
    return ilhaCatapulta3;
  else if(faseAtual == FASE_4)
    return ilhaCatapulta4;
  else
    return NULL;
}

/*! \brief Realiza a mudança de fase
 * \param myDot Barco do jogador
 * \param faseAtual A fase atual do jogo */
void mudaFase(Dot myDot, int *faseAtual, int *faseAnterior)
{
  int i;
  if((checaColisao(myDot->circulo,porto->circulo) == TRUE) && myDot->x + myDot->largura >= porto->x){
    StopMusic();
    myDot->musicaTocando = 0;
    myDot->x = 0;
    myDot->y = 0;
    myDot->angulo = 0.0;
    myDot->indiceVetor = 0.0;
    myDot->circulo->circuloX = myDot->x + (myDot->largura / 2);
    myDot->circulo->circuloY = myDot->y + (myDot->altura / 2);
    for(i = 0; i < 6; i++)
      myDot->ups[i] = FALSE;
    if(myDot->fase != FASE_4){
      *faseAnterior = myDot->fase;
      myDot->fase = UPGRADE;
    }
    if(myDot->fase == FASE_4)
      myDot->fase = YOU_WIN;
  }
  if(*faseAnterior == UPGRADE && myDot->fase != UPGRADE){
    if(myDot->fase - 1 == FASE_1){
      /*Vou para a fase 2*/
      bolasPosicao(50,50,2,ilhaCatapulta2,sereia1->objMonstro,sereia2->objMonstro,porto);
      *faseAnterior = FASE_1;
    }
    else if(myDot->fase - 1 == FASE_2){
      /*Vou para a fase 3*/
      bolasPosicao(50,50,3, cabecaMonstro3->next->objMonstro,cabecaMonstro3->next->next->objMonstro,cabecaMonstro3->next->next->next->objMonstro,porto);
      *faseAnterior = FASE_2;
    }
    else if(myDot->fase - 1 == FASE_3){
      /*Vou para a fase 4*/
      *faseAnterior = FASE_3;
    }
    else if(myDot->fase - 1 == FASE_4){
      *faseAnterior = FASE_4;
    }
  }
}

/*! \brief Executa a movimentação do barco de acordo com a fase atual 
 * \param myDot É o barco do jogador
 * \param faseAtual A fase atual do jogo */
void moveBarcoNaFase(Dot myDot, int *faseAtual)
{
  if(myDot->parado == FALSE)
    moveVento(myDot,SCREEN_WIDTH,SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR, listaMonstrosAtual(*faseAtual),listaIlhaCatapultaAtual(*faseAtual));
  moveBarco(myDot, SCREEN_WIDTH, SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR, listaMonstrosAtual(*faseAtual), listaIlhaCatapultaAtual(*faseAtual));
  if(*faseAtual == FASE_2){
    moveBarcoSereia(sereia1->objMonstro,myDot,250.0,4.0,cabecaMonstro2);
    moveBarcoSereia(sereia2->objMonstro,myDot,200.0,4.0,cabecaMonstro2);
  }
  if(*faseAtual == FASE_4){
    moveBarcoTornado(tornado1->objMonstro,myDot,200.0,cabecaMonstro4);
    moveBarcoTornado(tornado2->objMonstro,myDot,200.0,cabecaMonstro4);
    moveBarcoTornado(tornado3->objMonstro,myDot,200.0,cabecaMonstro4);
  }
  if(myDot->energia <= 0)
    myDot->fase = GAME_OVER;
}

/*! \brief Executa a movimentação dos ataques lançados na fase 
 * \param myDot Barco do jogador
 * \param faseAtual A fase atual do jogo */
void moveAtaques(Dot myDot, int *faseAtual)
{
  if(cabecaFlecha->next != NULL)
    moveAtaqueUnico(cabecaFlecha, listaMonstrosAtual(*faseAtual), myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
  if(cabecaBolaDeFogo->next != NULL)
    moveAtaqueUnico(cabecaBolaDeFogo, listaMonstrosAtual(*faseAtual), myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
  if(cabecaFlechaFogo->next != NULL)
    moveAtaqueUnico(cabecaFlechaFogo, listaMonstrosAtual(*faseAtual), myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
  if(cabecaRaio->next != NULL)
    moveAtaqueUnico(cabecaRaio, listaMonstrosAtual(*faseAtual), myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
  if(cabecaAguia->next != NULL)
    moveAtaqueArea(cabecaAguia, listaMonstrosAtual(*faseAtual), myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
}

/*! \brief Coloca os monstros na tela de acordo com a fase atual do jogo
 * \param myDot Barco do jogador
 * \param faseAtual A fase atual do jogo */
void aplicaMonstros(Dot myDot, int *faseAtual)
{
  int valorBarraVida;
  monstro inimigo;
  monstro cabecaMonstroAtual = listaMonstrosAtual(*faseAtual);
  for(inimigo = cabecaMonstroAtual->next; inimigo; inimigo = inimigo->next){
    if(*faseAtual == FASE_3 && inimigo->indicaMonstro == SERPENTE){
      if(inimigo->objMonstro->parado == FALSE)
        moveSerpente(inimigo,SCREEN_WIDTH,SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR);
      if(inimigo->sentidoMov == 1)
        apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorSerpente[1],screen,NULL);
      else if(inimigo->sentidoMov == -1)
        apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorSerpente[0],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 250);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura),
                    barraVidaInimigo[valorBarraVida],screen,NULL);
    }
    else if((*faseAtual == FASE_3 || *faseAtual == FASE_4) && inimigo->indicaMonstro == HARPIA){
      if(inimigo->objMonstro->parado == FALSE)
        moveHarpia(inimigo,SCREEN_WIDTH,SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR);
      if(inimigo->sentidoMov == 2 || inimigo->sentidoMov == 1)/*Desce ou esquerda*/
        apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorHarpia[0],screen,NULL);
      if(inimigo->sentidoMov == 0 || inimigo->sentidoMov == 3)/*Sobe ou direita*/
        apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorHarpia[1],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 100);
      apply_surface(inimigo->objMonstro->x, inimigo->objMonstro->y+(inimigo->objMonstro->altura),
                    barraVidaInimigo[valorBarraVida],screen,NULL);
    }
    else if(*faseAtual == FASE_4 && inimigo->indicaMonstro == KRAKEN){
      if(inimigo->objMonstro->parado == FALSE)
        moveKraken(inimigo,SCREEN_WIDTH,SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR);
      moveAtaque(myDot, inimigo);
      apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorKraken[0],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 500);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura),
                    barraVidaInimigo[valorBarraVida],screen,NULL);
      imprimeAtaqueKraken(vetorAtaqueKraken, screen);
    }
    else if(*faseAtual == FASE_1 && inimigo->indicaMonstro == BARCOINIMIGO){
      moveAtaqueBarcoInimigo(inimigo, myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
      apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorBarcoInimigo[inimigo->sentidoMov],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 150);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura), barraVidaInimigo[valorBarraVida],screen,NULL);
      imprimeAtaqueBarcoInimigo(vetorFlecha, screen);
    }
    else if(*faseAtual == FASE_3 && inimigo->indicaMonstro == BARCOINIMIGO){
      moveAtaqueBarcoInimigo(inimigo, myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
      apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorBarcoInimigo[inimigo->sentidoMov],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 150);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura), barraVidaInimigo[valorBarraVida],screen,NULL);
      imprimeAtaqueBarcoInimigo(vetorFlecha, screen);
    }
    else if(*faseAtual == FASE_4 && inimigo->indicaMonstro == BARCOINIMIGO){
      if(inimigo->objMonstro->parado == FALSE)
        moveBarcoInimigo(inimigo,SCREEN_WIDTH,SCREEN_HEIGHT - ALTURA_BARRA_INFERIOR);
      moveAtaqueBarcoInimigo(inimigo, myDot,SCREEN_WIDTH,SCREEN_HEIGHT);
      apply_surface(inimigo->objMonstro->x,inimigo->objMonstro->y,vetorBarcoInimigo[inimigo->sentidoMov],screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 150);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura), barraVidaInimigo[valorBarraVida],screen,NULL);
      imprimeAtaqueBarcoInimigo(vetorFlecha, screen);
    }
    else if((*faseAtual == FASE_1 || *faseAtual == FASE_2) && inimigo->indicaMonstro == CATAPULTA){
      lancaPedra(inimigo, myDot,SCREEN_HEIGHT);
      apply_surface(inimigo->objMonstro->x, inimigo->objMonstro->y, vetorCatapulta[0], screen,NULL);
      valorBarraVida = valorBarra(inimigo->objMonstro->vida, 400);
      apply_surface(inimigo->objMonstro->x+(int)(inimigo->objMonstro->largura/2)-22.5, inimigo->objMonstro->y+(inimigo->objMonstro->altura), barraVidaInimigo[valorBarraVida],screen,NULL);
      imprimePedra(vetorPedra, screen);
    }
  }
}

/*!\brief Coloca na tela os ataques lançados */
void aplicaAtaques()
{
  ataque celula;
  for(celula = cabecaFlecha->next; celula; celula = celula->next)
    apply_surface(celula->objAtaque->x,celula->objAtaque->y,vetorFlecha[(int)celula->objAtaque->indiceVetor], screen,NULL);
  for(celula = cabecaBolaDeFogo->next; celula; celula = celula->next)
    apply_surface(celula->objAtaque->x,celula->objAtaque->y,vetorBolaDeFogo[0], screen,NULL);
  for(celula = cabecaFlechaFogo->next; celula; celula = celula->next)
    apply_surface(celula->objAtaque->x,celula->objAtaque->y,vetorFlechaFogo[(int)celula->objAtaque->indiceVetor], screen,NULL);
  for(celula = cabecaRaio->next; celula; celula = celula->next)
    apply_surface(celula->objAtaque->x,celula->objAtaque->y,vetorRaio[((int)celula->objAtaque->indiceVetor)%8], screen,NULL);
  for(celula = cabecaAguia->next; celula; celula = celula->next)
    apply_surface(celula->objAtaque->x,celula->objAtaque->y,vetorAguia[(int)celula->objAtaque->indiceVetor], screen,NULL);
}

/*! \brief Aplica na parte inferior da tela as barras de vida, magia e energia do jogador
 * \param myDot Barco do jogador */
void aplicaBarrasInferiores(Dot myDot)
{
  int valorBarraVida, valorBarraMagia, valorBarraEnergia;
  valorBarraVida = valorBarra(myDot->vida, 200);
  apply_surface(30, 525, barraVida[valorBarraVida], screen, NULL);
  apply_surface(30 + (barraVida[valorBarraVida]->w / 2) - (nomeVida->w / 2), 525 - nomeVida->h, nomeVida, screen, NULL);
  valorBarraMagia = valorBarra(myDot->magia, 200);
  apply_surface(250, 525, barraMagia[valorBarraMagia], screen, NULL);
  apply_surface(250 + (barraMagia[valorBarraMagia]->w / 2) - (nomeMagia->w / 2), 525 - nomeMagia->h, nomeMagia, screen, NULL);
  valorBarraEnergia = valorBarra(myDot->energia, 200);
  apply_surface(470, 525, barraEnergia[valorBarraEnergia], screen, NULL);
  apply_surface(470 + (barraEnergia[valorBarraEnergia]->w / 2) - (nomeEnergia->w / 2), 525 - nomeEnergia->h, nomeEnergia, screen, NULL);
}

/*! \brief Função que chama as funções de movimentação do barco, dos ataques, aplicação das imagens, mudança de fase 
 * \param myDot Barco do jogador */
int fases(Dot myDot, int *faseAnterior)
{
  int *faseAtual = malloc(sizeof(int));
  char *pontuacao;
  SDL_Surface *gameOverMessage = TTF_RenderText_Solid(font, "GAME OVER", textColor);
  SDL_Surface *suaPontuacao = TTF_RenderText_Solid(font, "Sua pontuacao foi: ", textColor);
  SDL_Surface *youWinMessage = TTF_RenderText_Solid(font, "YOU WIN!", textColor);
  *faseAtual = myDot->fase;
  
  if(myDot->fase == GAME_OVER){
    StopMusic();
    apply_surface(0,0,gameOver,screen,NULL);
    if(entradaNome->texto != NULL){
      apply_surface((SCREEN_WIDTH - gameOverMessage->w)/2, (SCREEN_HEIGHT - entradaNome->texto->h) / 2 - 100,gameOverMessage,screen,NULL);
      apply_surface((SCREEN_WIDTH - entradaNome->texto->w) / 2, (SCREEN_HEIGHT - entradaNome->texto->h) / 2, entradaNome->texto, screen, NULL);
      apply_surface((SCREEN_WIDTH - suaPontuacao->w) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2 + 50, suaPontuacao, screen, NULL);
      apply_surface((SCREEN_WIDTH - points->w) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2 + 100, points, screen, NULL);
    }
    return GAME_OVER;
  }
  /*trata a mudanca de fase*/
  mudaFase(myDot,faseAtual,faseAnterior);
  if(myDot->fase == YOU_WIN){
    StopMusic();
    if(entradaNome->texto != NULL){
      apply_surface((SCREEN_WIDTH - youWinMessage->w)/2, (SCREEN_HEIGHT - entradaNome->texto->h) / 2 - 100,youWinMessage,screen,NULL);
      apply_surface((SCREEN_WIDTH - entradaNome->texto->w) / 2, (SCREEN_HEIGHT - entradaNome->texto->h) / 2 - 50, entradaNome->texto, screen, NULL);
      apply_surface((SCREEN_WIDTH - suaPontuacao->w) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2, suaPontuacao, screen, NULL);
      apply_surface((SCREEN_WIDTH - points->w) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2 + 50, points, screen, NULL);
    }
    if(bateuRanking == FALSE){
      bateuRanking = checaPontuacao(entradaNome->nome, myDot->pontos); /************/
      if(bateuRanking == TRUE){
        imagensRanking(posicaoRanking, nomesRanking, pontuacaoRanking, font, textColor);
        telaRanking = load_image("imagens/telas/ranking.png");
        novoRanking = TTF_RenderText_Solid(font, "Parabens! Novo recorde!", textColor);
        botaoRanking = Botao((SCREEN_WIDTH - 65) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2 + 150 , 65, 50, 0);
      }
    }
    return YOU_WIN;
  }
  if(myDot->fase == RANKING){
    StopMusic();
    apply_surface(0,0,telaRanking,screen,NULL);
    apply_surface(100,130,posicaoRanking[0],screen,NULL);    
    apply_surface(200,130,nomesRanking[0],screen,NULL);
    apply_surface(680,130,pontuacaoRanking[0],screen,NULL);
    apply_surface(100,160,posicaoRanking[1],screen,NULL);    
    apply_surface(200,160,nomesRanking[1],screen,NULL);
    apply_surface(680,160,pontuacaoRanking[1],screen,NULL);
    apply_surface(100,190,posicaoRanking[2],screen,NULL);    
    apply_surface(200,190,nomesRanking[2],screen,NULL);
    apply_surface(680,190,pontuacaoRanking[2],screen,NULL);
    apply_surface(100,220,posicaoRanking[3],screen,NULL);    
    apply_surface(200,220,nomesRanking[3],screen,NULL);
    apply_surface(680,220,pontuacaoRanking[3],screen,NULL);
    apply_surface(100,250,posicaoRanking[4],screen,NULL);    
    apply_surface(200,250,nomesRanking[4],screen,NULL);
    apply_surface(680,250,pontuacaoRanking[4],screen,NULL);
    apply_surface(100,280,posicaoRanking[5],screen,NULL);    
    apply_surface(200,280,nomesRanking[5],screen,NULL);
    apply_surface(680,280,pontuacaoRanking[5],screen,NULL);
    apply_surface(100,310,posicaoRanking[6],screen,NULL);    
    apply_surface(200,310,nomesRanking[6],screen,NULL);
    apply_surface(680,310,pontuacaoRanking[6],screen,NULL);
    apply_surface(100,340,posicaoRanking[7],screen,NULL);    
    apply_surface(200,340,nomesRanking[7],screen,NULL);
    apply_surface(680,340,pontuacaoRanking[7],screen,NULL);
    apply_surface(100,370,posicaoRanking[8],screen,NULL);    
    apply_surface(200,370,nomesRanking[8],screen,NULL);
    apply_surface(680,370,pontuacaoRanking[8],screen,NULL);
    apply_surface(100,400,posicaoRanking[9],screen,NULL);    
    apply_surface(200,400,nomesRanking[9],screen,NULL);
    apply_surface(680,400,pontuacaoRanking[9],screen,NULL);
    return RANKING;
  }
  /*Move o barco na fase*/
  moveBarcoNaFase(myDot,faseAtual);
  /*Move os ataques lancados pelo barco*/
  moveAtaques(myDot,faseAtual);
  /*Preenche a tela*/
  SDL_FillRect(screen, &screen->clip_rect, SDL_MapRGB(screen->format, 0xFF, 0xFF, 0xFF));
  /*Aplica o plano de fundo*/
  apply_surface(0, 0, background, screen, NULL);
  if(*faseAtual == FASE_1 || *faseAtual == FASE_2)
    apply_surface(ilhaCatapulta->x, ilhaCatapulta->y, vetorIlhaCatapulta[0], screen, NULL);
  apply_surface(porto->x,porto->y,imagemPorto,screen,NULL);
  if(*faseAtual == FASE_2){
    apply_surface(sereia1->objMonstro->x,sereia1->objMonstro->y,vetorSereia[0],screen,NULL);
    apply_surface(sereia2->objMonstro->x,sereia2->objMonstro->y,vetorSereia[0],screen,NULL);
  }
  if(*faseAtual == FASE_4){
    apply_surface(tornado1->objMonstro->x,tornado1->objMonstro->y,vetorTornado[0], screen,NULL);
    apply_surface(tornado2->objMonstro->x,tornado2->objMonstro->y,vetorTornado[0], screen,NULL);
    apply_surface(tornado3->objMonstro->x,tornado3->objMonstro->y,vetorTornado[0], screen,NULL);
  }
  if(myDot->fase == FASE_1 || myDot->fase == FASE_2 || myDot->fase == FASE_3)
    imprimeBolas(screen,myDot);
  /*aplica o barco do jogador*/
  apply_surface(myDot->x, myDot->y, barcoJogador[(int)myDot->indiceVetor], screen, NULL);
  /*aplica os monstros*/
  aplicaMonstros(myDot,faseAtual);  
  pontuacao = converteInteiroString(myDot->pontos);
  points = TTF_RenderText_Solid(font, pontuacao, textColor);
  message = TTF_RenderText_Solid(font, "Points", textColor);
  if(message == NULL || points == NULL)
    return 1;
  /*aplica na tela os ataques lancados*/
  aplicaAtaques();
  /*aplica barra de vida, energia e magia*/
  aplicaBarrasInferiores(myDot);
  apply_surface(770, 515, message, screen, NULL);
  apply_surface(770 - points->w - 5, 515, points, screen, NULL);
  free(pontuacao);
  free(faseAtual);
  SDL_FreeSurface (gameOverMessage);
  SDL_FreeSurface (suaPontuacao);
  SDL_FreeSurface (youWinMessage);
  return 0;
}

/*! \brief Libera a memória usada pelo jogo e encerra a SDL*/
void clean_up()
{
  int i;
  ataque removeAtaque;
  for(i = 0; i < 41; i++){
    SDL_FreeSurface(barraVida[i]);
    SDL_FreeSurface(barraVidaInimigo[i]);
    SDL_FreeSurface(barraMagia[i]);
    SDL_FreeSurface(barraEnergia[i]);
  }
  SDL_FreeSurface(nomeVida);
  SDL_FreeSurface(nomeMagia);
  SDL_FreeSurface(nomeEnergia);
  for(i = 0; i < 16; i++){
    SDL_FreeSurface(barcoJogador[i]);
    SDL_FreeSurface(vetorFlecha[i]);
    SDL_FreeSurface(vetorFlechaFogo[i]);
    SDL_FreeSurface(vetorAguia[i]);
  }
  for(i = 0; i < 12; i++)
    SDL_FreeSurface(vetorBotoesUps[i]);
  for(i = 0; i < 8; i++)
    SDL_FreeSurface(vetorRaio[i]);
  for(i = 0; i < 4; i++)
    SDL_FreeSurface(vetorBarcoInimigo[i]);
  for(i = 0; i < 2; i++){
    SDL_FreeSurface(vetorSerpente[i]);
    SDL_FreeSurface(vetorHarpia[i]);
    SDL_FreeSurface(vetorBotaoPular[i]);
    SDL_FreeSurface(vetorBotaoCreditos[i]);
    SDL_FreeSurface(vetorBotaoInstrucoes[i]);
    SDL_FreeSurface(vetorBotaoComecar[i]);
    SDL_FreeSurface(vetorBotaoInicial[i]);
    SDL_FreeSurface(vetorBotaoSom[i]);
    SDL_FreeSurface(vetorBotaoAnterior[i]);
    SDL_FreeSurface(vetorBotaoJogar[i]);
    SDL_FreeSurface(vetorBotaoProximo[i]);
    SDL_FreeSurface(vetorBotaoRanking[i]);
  }

  for(i = 0; i < 1; i++){
    SDL_FreeSurface(vetorKraken[i]);
    SDL_FreeSurface(vetorAtaqueKraken[i]);	
    SDL_FreeSurface(vetorSereia[i]);
    SDL_FreeSurface(vetorTornado[i]);
    SDL_FreeSurface(vetorCatapulta[i]);
    SDL_FreeSurface(vetorPedra[i]);
    SDL_FreeSurface(vetorBolaDeFogo[i]);
    SDL_FreeSurface(vetorIlhaCatapulta[i]);
  }
  SDL_FreeSurface(menu);
  SDL_FreeSurface(background);
  SDL_FreeSurface(screen);
  SDL_FreeSurface(tela1);
  SDL_FreeSurface(tela2);
  SDL_FreeSurface(tela3);
  SDL_FreeSurface(youWin);
  SDL_FreeSurface(gameOver);
  SDL_FreeSurface(upgrades);
  if(message != NULL)
    SDL_FreeSurface(message);
  SDL_FreeSurface(points);
  SDL_FreeSurface(instrucoes1);
  SDL_FreeSurface(instrucoes2);
  SDL_FreeSurface(creditos);
  if(telaEntradaNome != NULL)
    SDL_FreeSurface(telaEntradaNome);
  SDL_FreeSurface(imagemPorto);
  if(mensagemUp)
    SDL_FreeSurface(mensagemUp);
  for(i = 0; i < 5; i++)
    Mix_FreeMusic(music[i]);
  TTF_CloseFont(font);
  liberaAtaqueKraken();
  liberaPedra();
  liberaAtaquesBarcoInimigo();
  liberaBolas();
  liberaDot(ilhaCatapulta);
  liberaDot(porto);
  liberaDot(ilhaCatapulta1);
  liberaDot(ilhaCatapulta2);
  liberaDot(ilhaCatapulta3);
  liberaDot(ilhaCatapulta4);
  liberaBotao(upAguia);
  liberaBotao(upFlechaFogo);
  liberaBotao(upBolsaVentos);
  liberaBotao(vidaUp);
  liberaBotao(upMagia);
  liberaBotao(upEnergia);
  liberaBotao(botaoProximo);
  liberaBotao(botaoJogar);
  liberaBotao(botaoPular);
  liberaBotao(botaoCreditos);
  liberaBotao(botaoInstrucoes);
  liberaBotao(botaoComecar);
  liberaBotao(botaoInicial);
  liberaBotao(botaoSom);
  liberaBotao(botaoAnterior);
  liberaNome(entradaNome);
  for(removeAtaque = cabecaFlecha; removeAtaque; removeAtaque = cabecaFlecha){
    cabecaFlecha = cabecaFlecha->next;
    liberaAtaque(removeAtaque);
  }
  for(removeAtaque = cabecaBolaDeFogo; removeAtaque; removeAtaque = cabecaBolaDeFogo){
    cabecaBolaDeFogo = cabecaBolaDeFogo->next;
    liberaAtaque(removeAtaque);
  }
  for(removeAtaque = cabecaFlechaFogo; removeAtaque; removeAtaque = cabecaFlechaFogo){
    cabecaFlechaFogo = cabecaFlechaFogo->next;
    liberaAtaque(removeAtaque);
  }
  for(removeAtaque = cabecaRaio; removeAtaque; removeAtaque = cabecaRaio){
    cabecaRaio = cabecaRaio->next;
    liberaAtaque(removeAtaque);
  }
  for(removeAtaque = cabecaAguia; removeAtaque; removeAtaque = cabecaAguia){
    cabecaAguia = cabecaAguia->next;
    liberaAtaque(removeAtaque);
  }
  for(removeAtaque = cabecaCatapulta; removeAtaque; removeAtaque = cabecaCatapulta){
    cabecaCatapulta = cabecaCatapulta->next;
    liberaAtaque(removeAtaque);
  }
  for(apontaMonstro1 = cabecaMonstro1; apontaMonstro1; apontaMonstro1 = cabecaMonstro1){
    cabecaMonstro1 = cabecaMonstro1->next;
    liberaMonstro(apontaMonstro1);
  }
  for(apontaMonstro2 = cabecaMonstro2; apontaMonstro2; apontaMonstro2 = cabecaMonstro2){
    cabecaMonstro2 = cabecaMonstro2->next;
    liberaMonstro(apontaMonstro2);
  }
  for(apontaMonstro3 = cabecaMonstro3; apontaMonstro3; apontaMonstro3 = cabecaMonstro3){
    cabecaMonstro3 = cabecaMonstro3->next;
    liberaMonstro(apontaMonstro3);
  }
  for(apontaMonstro4 = cabecaMonstro4; apontaMonstro4; apontaMonstro4 = cabecaMonstro4){
    cabecaMonstro4 = cabecaMonstro4->next;
    liberaMonstro(apontaMonstro4);
  }
  if(bateuRanking == TRUE){
    for(i = 0; i < 10; i++){
      SDL_FreeSurface(posicaoRanking[i]); 
      SDL_FreeSurface(nomesRanking[i]);
      SDL_FreeSurface(pontuacaoRanking[i]);
    }
    SDL_FreeSurface(novoRanking);
    SDL_FreeSurface(telaRanking);
    liberaBotao(botaoRanking);
  }
  Mix_CloseAudio();
  TTF_Quit();
  SDL_Quit();
}

/*! \brief Inicializa todos os botões usados no jogo. As posições dos botões mudarão de acordo com as telas */
void inicializaTodosBotoes()
{
  upAguia = Botao(100,100,117,90,0);
  upFlechaFogo = Botao(250, 100, 117,90,4);
  upBolsaVentos = Botao(400, 100, 117, 90,2);
  vidaUp = Botao(100,250,117,90,6);
  upMagia = Botao(250,250,117,90,8);
  upEnergia = Botao(400, 250, 117, 90,10);
  botaoProximo = Botao(800, 250, 50, 25,0);
  botaoComecar = Botao(800,250,50,25,0);
  botaoJogar = Botao(750, 250, 65, 50,0);
  botaoInstrucoes = Botao(750, 320, 65, 50,0);
  botaoCreditos = Botao(750, 390, 65, 50,0);
  botaoSom = Botao(750, 450,39,39,0);
  botaoInicial = Botao(397, 430, 65, 50,0);
  botaoPular = Botao(800, 300, 50, 25, 0);
  botaoAnterior = Botao(800,200,55,30,0);
}

/*! \brief Detecta qual botão foi apertado e faz a atualização de fase de jogo
 * \param myDot Barco do jogador
 * \param faseAnterior Fase anterior do jogo (pode também ser uma tela de menu, enredo, instruções, por exemplo)
 * \param upTimer Timer para a mensagem aparecer na tela de upgrades */
void detectaBotao(Dot myDot, int *faseAnterior, Timer upTimer)
{
  if(myDot->fase == MENU && handle_events(botaoSom,event)){
    comSom = !comSom;
  }
  if(handle_events(botaoProximo, event)){ /**********/
    if(myDot->fase == ENREDO1 || myDot->fase == ENREDO2){
      myDot->fase++;
    }
    else if(myDot->fase == UPGRADE && *faseAnterior != FASE_4){
      myDot->fase = *faseAnterior + 1;
      *faseAnterior = UPGRADE;
    }
    else if(myDot->fase == INSTRUCOES1)
      myDot->fase = INSTRUCOES2;
  }
  if((myDot->fase == ENREDO2 || myDot->fase == ENREDO3 || myDot->fase == INSTRUCOES2) && handle_events(botaoAnterior,event)){
    myDot->fase--;
  }
  if(myDot->fase == ENREDO3 && handle_events(botaoComecar, event)){
    myDot->fase = FASE_1;
    StopMusic();
    myDot->musicaTocando = FALSE;
  }
  if(myDot->fase < ENREDO3 && handle_events(botaoPular, event)){
    myDot->fase = FASE_1;
    StopMusic();
    myDot->musicaTocando = FALSE;
  }
  if(myDot->fase == MENU && handle_events(botaoInstrucoes, event)){
    myDot->fase = INSTRUCOES1;
  }
  if(myDot->fase == MENU && handle_events(botaoCreditos, event)){
    myDot->fase = CREDITOS;
  }
  if((myDot->fase == CREDITOS || myDot->fase == INSTRUCOES1 || myDot->fase == INSTRUCOES2) &&  handle_events(botaoInicial, event)){
    myDot->fase = MENU;
  }
  if((myDot->fase == MENU || myDot->fase == INSTRUCOES2) && telaEntradaNome == NULL && handle_events(botaoJogar, event)){
    telaEntradaNome = load_image("imagens/telas/telaEntradaNome.png");
  }
  if((myDot->fase == MENU || myDot->fase == INSTRUCOES2) && telaEntradaNome && entrouNome == FALSE){
    handle_stringInput(entradaNome, event, font, textColor);
    if((event.type == SDL_KEYDOWN) && (event.key.keysym.sym == SDLK_RETURN)){
      myDot->fase = ENREDO1;
      entrouNome = TRUE;
      SDL_FreeSurface(message);
      message = NULL;
      SDL_FreeSurface(telaEntradaNome);
      telaEntradaNome = NULL;
      endStringInput(entradaNome);
    }
  }
  if(myDot->fase == YOU_WIN && bateuRanking == TRUE && handle_events(botaoRanking, event))
    myDot->fase = RANKING;
  if(handle_events(upAguia,event)){
    mensagemUp = NULL;
    if(myDot->ups[UP_AGUIA] == FALSE){
      if(myDot->pontos >= 500){
	myDot->ups[UP_AGUIA] = TRUE;
	myDot->pontos -= 500;
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up aguia de zeus!\n",textColor); 
	stop(upTimer);
      }
      else
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
  if(handle_events(upFlechaFogo,event)){
    if(myDot->ups[UP_FLECHAFOGO] == FALSE){
      if(myDot->pontos >= 100){
	myDot->ups[UP_FLECHAFOGO] = TRUE;
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up de flechas de fogo!\n",textColor);
	myDot->pontos -= 100;
	stop(upTimer);
      }
      else
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
  if(handle_events(upBolsaVentos,event)){
    if(myDot->ups[UP_BOLSAVENTOS] == FALSE){
      if(myDot->pontos >= 25){
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up bolsa de ventos!\n",textColor);
	myDot->ups[UP_BOLSAVENTOS] = TRUE;
	myDot->pontos -= 25;
	stop(upTimer);
      }
      else
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
  if(handle_events(vidaUp, event)){
    if(myDot->ups[UP_VIDA] == FALSE){
      if(myDot->pontos >= 10){
	myDot->vida += 50;
	myDot->ups[UP_VIDA] = TRUE;
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up de vidas extras!\n",textColor);
	myDot->pontos -= 10;
	stop(upTimer);
      }
      else
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
  if(handle_events(upMagia, event)){
    if(myDot->ups[UP_MAGIA] == FALSE){
      if(myDot->pontos >= 10){
	myDot->magia += 50;
	myDot->ups[UP_MAGIA] = TRUE;
	myDot->pontos -= 10;
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up de magia extra!\n",textColor);
	stop(upTimer);
      }
      else 
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
  if(handle_events(upEnergia,event)){
    if(myDot->ups[UP_ENERGIA] == FALSE){
      if(myDot->pontos >= 10){
	myDot->energia += 50;
	myDot->ups[UP_ENERGIA] = TRUE;
	myDot->pontos -= 10;
	mensagemUp = TTF_RenderText_Solid(font, "Voce comprou o up de energia extra!\n",textColor);
      }
      else
	mensagemUp = TTF_RenderText_Solid(font, "Voce nao tem pontos suficiente para esse upgrade!", textColor);
    }
    else
      mensagemUp = TTF_RenderText_Solid(font, "Voce ja comprou esse upgrade!", textColor);
  }
}

/*! \brief Aplica as telas do jogo de acordo com a fase atual
 * \param myDot Barco do jogador
 * \param pontuacao String com a pontuação do jogador 
 * \param pontos Superfície com os pontos do jogador
 * \param orientacaoNome Superfície orientando o usuário em como proceder após digitar seu nome 
 * \param faseAnterior Etapa anterior do jogo, pode ser uma fase ou uma tela funcional (enredo,instrução,...) do jogo
 * \param upTimer Timer para a mensagem aparecer na tela de upgrades */
void aplicaTelas(Dot myDot, char *pontuacao, SDL_Surface *pontos, SDL_Surface *orientacaoNome, int *faseAnterior, Timer upTimer)
{
  if(myDot->fase == MENU){
    apply_surface(0, 0, menu, screen, NULL);
    botaoJogar->caixa.x = 750;
    botaoJogar->caixa.y = 250;
    apply_surface(botaoJogar->caixa.x, botaoJogar->caixa.y, vetorBotaoJogar[botaoJogar->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoInstrucoes->caixa.x,botaoInstrucoes->caixa.y,vetorBotaoInstrucoes[botaoInstrucoes->indiceBotaoAtual],screen,NULL);
    apply_surface(botaoCreditos->caixa.x, botaoCreditos->caixa.y, vetorBotaoCreditos[botaoCreditos->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoSom->caixa.x, botaoSom->caixa.y, vetorBotaoSom[!comSom], screen, NULL);
    if(telaEntradaNome != NULL){
      apply_surface(230, 180, telaEntradaNome, screen, NULL);
      apply_surface((SCREEN_WIDTH - message->w)/2, (SCREEN_HEIGHT / 2) - (2 * message->h), message, screen, NULL);
      orientacaoNome = TTF_RenderText_Solid(font, "-Tecle enter depois de digitar seu nome-", textColor);
      apply_surface((SCREEN_WIDTH - orientacaoNome->w)/2, (SCREEN_HEIGHT / 2) - (2 * message->h) + 30, orientacaoNome, screen, NULL);
      show_centered(entradaNome, SCREEN_WIDTH, SCREEN_HEIGHT, screen);
    }
  }
  if(myDot->fase == INSTRUCOES1){
    apply_surface(0,0,instrucoes1,screen,NULL);
    botaoProximo->caixa.x = 750;
    botaoProximo->caixa.y = 250;
    apply_surface(botaoProximo->caixa.x, botaoProximo->caixa.y, vetorBotaoProximo[botaoProximo->indiceBotaoAtual], screen, NULL);
    botaoInicial->caixa.x = 750;
    botaoInicial->caixa.y = 320;
    apply_surface(botaoInicial->caixa.x, botaoInicial->caixa.y, vetorBotaoInicial[botaoInicial->indiceBotaoAtual], screen, NULL);
  }
  if(myDot->fase == INSTRUCOES2){
    apply_surface(0, 0, instrucoes2, screen, NULL);
    botaoJogar->caixa.x = 750;
    botaoJogar->caixa.y = 470;
    apply_surface(botaoJogar->caixa.x, botaoJogar->caixa.y, vetorBotaoJogar[botaoJogar->indiceBotaoAtual], screen, NULL);
    botaoInicial->caixa.x = 650;
    botaoInicial->caixa.y = 470;
    apply_surface(botaoInicial->caixa.x, botaoInicial->caixa.y, vetorBotaoInicial[botaoInicial->indiceBotaoAtual], screen, NULL);
    botaoAnterior->caixa.x = 550;
    botaoAnterior->caixa.y = 470;
    apply_surface(botaoAnterior->caixa.x, botaoAnterior->caixa.y, vetorBotaoAnterior[botaoAnterior->indiceBotaoAtual], screen, NULL);
    if(telaEntradaNome != NULL){
      apply_surface(230, 180, telaEntradaNome, screen, NULL);
      apply_surface((SCREEN_WIDTH - message->w)/2, (SCREEN_HEIGHT / 2) - (2 * message->h), message, screen, NULL);
      orientacaoNome = TTF_RenderText_Solid(font, "-Tecle enter depois de digitar seu nome-", textColor);
      apply_surface((SCREEN_WIDTH - orientacaoNome->w)/2, (SCREEN_HEIGHT / 2) - (2 * message->h) + 30, orientacaoNome, screen, NULL);
      show_centered(entradaNome, SCREEN_WIDTH, SCREEN_HEIGHT, screen);
    }
  }
  if(myDot->fase == CREDITOS){
    apply_surface(0, 0, creditos, screen, NULL);
    botaoInicial->caixa.x = 397;
    botaoInicial->caixa.y = 430;
    apply_surface(botaoInicial->caixa.x,botaoInicial->caixa.y,vetorBotaoInicial[botaoInicial->indiceBotaoAtual],screen,NULL);
  }
  if(myDot->fase == ENREDO1){
    if(comSom)
      if(myDot->musicaTocando == FALSE){
	PlayMusic(music,4);
      	myDot->musicaTocando = TRUE;
      }
    apply_surface(0, 0, tela1, screen, NULL);
    botaoProximo->caixa.x = 800;
    botaoProximo->caixa.y = 250;
    apply_surface(botaoProximo->caixa.x, botaoProximo->caixa.y, vetorBotaoProximo[botaoProximo->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoPular->caixa.x, botaoPular->caixa.y, vetorBotaoPular[botaoPular->indiceBotaoAtual], screen, NULL);
  }
  if(myDot->fase == ENREDO2){
    apply_surface(0, 0, tela2, screen, NULL);
    botaoAnterior->caixa.x = 800;
    botaoAnterior->caixa.y = 200;
    apply_surface(botaoAnterior->caixa.x, botaoAnterior->caixa.y, vetorBotaoAnterior[botaoAnterior->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoProximo->caixa.x, botaoProximo->caixa.y, vetorBotaoProximo[botaoProximo->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoPular->caixa.x, botaoPular->caixa.y, vetorBotaoPular[botaoPular->indiceBotaoAtual], screen, NULL);
  }
  if(myDot->fase == ENREDO3){
    apply_surface(0, 0, tela3, screen, NULL);
    apply_surface(botaoAnterior->caixa.x, botaoAnterior->caixa.y, vetorBotaoAnterior[botaoAnterior->indiceBotaoAtual], screen, NULL);
    apply_surface(botaoComecar->caixa.x, botaoComecar->caixa.y, vetorBotaoComecar[botaoPular->indiceBotaoAtual], screen, NULL);
  }
  if(myDot->fase == UPGRADE && !faseAnterior != FASE_4){
    apply_surface(0, 0, upgrades, screen, NULL);
    botaoProximo->caixa.x = 750;
    apply_surface(botaoProximo->caixa.x, botaoProximo->caixa.y, vetorBotaoProximo[botaoProximo->indiceBotaoAtual], screen, NULL);
    apply_surface(upAguia->caixa.x,upAguia->caixa.y,vetorBotoesUps[upAguia->indiceBotaoAtual],screen,NULL);
    apply_surface(upBolsaVentos->caixa.x,upBolsaVentos->caixa.y,vetorBotoesUps[upBolsaVentos->indiceBotaoAtual],screen,NULL);
    apply_surface(upFlechaFogo->caixa.x,upFlechaFogo->caixa.y,vetorBotoesUps[upFlechaFogo->indiceBotaoAtual],screen,NULL);
    apply_surface(vidaUp->caixa.x,vidaUp->caixa.y,vetorBotoesUps[vidaUp->indiceBotaoAtual],screen,NULL);
    apply_surface(upMagia->caixa.x,upMagia->caixa.y,vetorBotoesUps[upMagia->indiceBotaoAtual],screen,NULL);
    apply_surface(upEnergia->caixa.x,upEnergia->caixa.y,vetorBotoesUps[upEnergia->indiceBotaoAtual],screen,NULL);
    message = TTF_RenderText_Solid(font,"Points",textColor);
    apply_surface(780, 450, message, screen, NULL);
    apply_surface(730, 450, pontos, screen, NULL);
    if(mensagemUp != NULL){
      if(!is_started(upTimer))
	start(upTimer);
      if(get_ticks(upTimer) <= 5000)
	apply_surface(100, 450, mensagemUp, screen, NULL);
      else{
        SDL_FreeSurface(mensagemUp);
	mensagemUp = NULL;
	stop(upTimer);
      }
    }
  }
  if(myDot->fase == YOU_WIN){
    apply_surface(0, 0, youWin, screen, NULL);
    if(bateuRanking == TRUE){
      apply_surface((SCREEN_WIDTH - novoRanking->w) / 2 , (SCREEN_HEIGHT - entradaNome->texto->h) / 2 + 100, novoRanking, screen, NULL);
      apply_surface(botaoRanking->caixa.x , botaoRanking->caixa.y, vetorBotaoRanking[botaoRanking->indiceBotaoAtual], screen, NULL);
    }
  }
}

/*! \brief Toca a música de acordo com a fase atual 
 * \param myDot Barco do jogador, do qual se obtem a fase atual */
void playMusicFase(Dot myDot)
{
  if(myDot->fase == FASE_1 && myDot->musicaTocando == 0){
    PlayMusic(music,0);
    myDot->musicaTocando = 1;
  }	
  else if(myDot->fase == FASE_2 && myDot->musicaTocando == 0){
    PlayMusic(music,1);
    myDot->musicaTocando = 1;
  }
  else if(myDot->fase == FASE_3 && myDot->musicaTocando == 0){
    PlayMusic(music,2);
    myDot->musicaTocando = 1;
  }
  else if(myDot->fase == FASE_4 && myDot->musicaTocando == 0){
    PlayMusic(music,3);
    myDot->musicaTocando = 1;
  }
}

/*! \brief Função main do jogo*/
int main(int argc, char* args[])
{
  /*Quit flag*/
  int quit = FALSE;
  int *faseAnterior = malloc(sizeof(int));
  /*O barco do jogador*/
  Dot myDot;
  /*O regulador da taxa de frames*/
  Timer fps;
  Timer upTimer = initTimer();
  /*Pontuacao que aparece nos ups */
  char *pontuacao;
  SDL_Surface *pontos;
  /*Instrucao do que fazer apos digitar nome (teclar enter)*/
  SDL_Surface *orientacaoNome = NULL;
  myDot = initDot(0, 0, 70, 70, 200, FALSE, 0.0);
  myDot->energia = 200;
  myDot->magia = 200;
  myDot->fase = MENU;
  fps = initTimer();
  inicializaTodosBotoes();
  srand(time(NULL));
  /*Inicilização*/
  if(init() == FALSE)
    return 1;
  /*Carrega os arquivos*/
  if(load_files() == FALSE){
    return 1;
  }
  bolasPosicao(20,20,1,ilhaCatapulta1, cabecaMonstro1->next->objMonstro,NULL,porto);
  entradaNome = initStringInput();
  message = TTF_RenderText_Solid(font, "Nome do jogador", textColor);

  /*Inicializa o ranking*/
  abreRanking(); /*************/

  /*Enquanto o usuario nao quiser sair*/
  while(quit == FALSE){
    /*Inicia o timer*/
    start(fps);
    /*Enquanto ha eventos */
    while(SDL_PollEvent(&event)){
      detectaBotao(myDot,faseAnterior,upTimer);
      handle_input(myDot, event, cabecaFlecha, cabecaBolaDeFogo, cabecaFlechaFogo, cabecaRaio, cabecaAguia);
      pontuacao = converteInteiroString(myDot->pontos);
      pontos = TTF_RenderText_Solid(font, pontuacao, textColor);
      /*Se o usuario fechou a janela*/
      if(event.type == SDL_QUIT){
	/*Quit the program*/
	quit = TRUE;
      }
    }
    aplicaTelas(myDot,pontuacao,pontos,orientacaoNome,faseAnterior,upTimer);
    if(myDot->fase == FASE_1 || myDot->fase == FASE_2 || myDot->fase == FASE_3 || myDot->fase == FASE_4 || myDot->fase == YOU_WIN || myDot->fase == GAME_OVER || myDot->fase == RANKING){
      fases(myDot,faseAnterior);
      if(comSom){
	playMusicFase(myDot);
      }
    }
    /*Atualiza a tela*/
    if(SDL_Flip(screen) == -1)
      return 1;
    /*captura a taxa de frames*/
    if(get_ticks(fps) < 1000 / FRAMES_PER_SECOND)
      SDL_Delay((1000 / FRAMES_PER_SECOND) - get_ticks(fps));
  }
  /*Encerra*/
  free(faseAnterior);
  liberaDot(myDot);
  free(fps);
  free(upTimer);
  free(pontuacao);
  SDL_FreeSurface(pontos);
  SDL_FreeSurface(orientacaoNome);
  liberaRanking(); /****************/
  clean_up();
  return 0;
}
