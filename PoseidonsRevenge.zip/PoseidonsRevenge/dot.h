/*! \file dot.h
 * \brief Interface de dot.c com a definição do tipo Dot */

#include "colisao.h"
#define UP_AGUIA 0
#define UP_FLECHAFOGO 1
#define UP_BOLSAVENTOS 2
#define UP_VIDA 3
#define UP_MAGIA 4
#define UP_ENERGIA 5

/*! \breif Tipo que é usado em todos os personagens do jogo. Em sua estrutura estão informações importantes de cada objeto: posição, vida, dimensões, o indice da imagem a ser usada, entre outros */
typedef struct dot *Dot;
/*! \brief Estrutura usada para representar o tipo dot */
struct dot{
  /*! \brief Atual coordenada x do objeto */
  int x;
  /*! \brief Atual coordenada y do objeto */
  int y;
  /*! \brief Largura da imagem do objeto */
  int largura;
  /*! \brief Altura da imagem do objeto */
  int altura;
  /*! \brief A distancia que o objeto deve percorrer */
  int distanciaPercorrida;
  /*! \brief Quantidade de vida do objeto. Usado no barco principal e nos monstros */
  int vida;
  /*! \brief Quantidade de energia do objeto. Usado no barco principal */
  int energia;
  /*! \brief Quantidade de magia do objeto. Usado no barco principal */
  int magia;
  /*! \brief Os pontos acumulados pelo jogador */
  int pontos;
  /*! \brief Vale 1 se o objeto esta parado, 0 caso o objeto esteja em movimento */
  int parado;
  /*! \brief O angulo de inclinacao do objeto. Muito usado pelo barco principal */
  float angulo;
  /*! \brief Indica a posicao do vetor para a imagem correspondente a inclinacao atual do objeto */
  float indiceVetor;
  /*! \brief Circulo do objeto para a colisao */
  circ circulo;
  /*! \brief Inidica a fase do objeto. Usado pelo barco principal para a mudanca de fase */
  int fase;
  /*! \brief Vale 1 se ha alguma musica tocando, 0 caso contrario */
  int musicaTocando;
  /*! \brief ups[i] == 1 indica que o jogador comprou o up i. Ver defines acima.*/
  int ups[6];
};

Dot initDot(int x, int y, int width, int height, int life, int stop, float angle);

void liberaDot(Dot libera);

void show(Dot dot, SDL_Surface **imageDot, SDL_Surface *background, SDL_Surface *screen);
