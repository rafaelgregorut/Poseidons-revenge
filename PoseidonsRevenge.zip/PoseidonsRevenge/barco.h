/*! \file barco.h
 * \brief Interface de barco.c */
#include "ataque.h"

void carregaVetorImagensBarcoJogador(SDL_Surface **barcoJogador);

void carregaBarraVida(SDL_Surface **barraVida);

void carregaBarraMagia(SDL_Surface **barraMagia);

void carregaBarraVidaInimigo(SDL_Surface **barraVidaInimigo);

void carregaBarraEnergia(SDL_Surface **barraEnergia);

void handle_input(Dot dot, SDL_Event event, ataque flecha, ataque bolaDeFogo, ataque flechaFogo, ataque raio, ataque aguia);

void moveVento(Dot dot, int SCREEN_WIDTH, int SCREEN_HEIGHT, monstro cabecaMonstro, Dot ilhaCatapulta);

void moveBarco(Dot dot, int SCREEN_WIDTH, int SCREEN_HEIGHT, monstro cabecaMonstro, Dot ilhaCatapulta);
