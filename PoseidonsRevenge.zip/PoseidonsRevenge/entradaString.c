/*! \file entradaString.c
 * \brief Arquivo com as funções que lidam com a captura do nome do usuário. Essas funções foram baseadas nos tutoriais de SDL do lazyfoo*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "entradaString.h"
#include "image.h"

/*! \brief Inicializa a variável onde será armazenado o nome
 * \return Objeto onde será guardado o nome do usuário */
nom initStringInput()
{
  nom novo;
  novo = malloc(sizeof *novo);
  novo->nome = calloc(15, sizeof (char));;
  novo->nome[0] = '\0';
  novo->indiceVetor = 0;
  novo->texto = NULL;
  SDL_EnableUNICODE(SDL_ENABLE);
  return novo;
}

/*! \brief Desativa a captura de chars com UNICODE */
void endStringInput(nom entrada)
{
  SDL_EnableUNICODE(SDL_DISABLE);
}

/*! \brief Libera uma nome
 * \param libera O nome a ser liberado */
void liberaNome(nom libera)
{
  if(libera){
    if(libera->nome)
      free(libera->nome);
    libera->nome = NULL;
    if(libera->texto)
      SDL_FreeSurface(libera->texto);
    libera->texto = NULL;
    free(libera);
    libera = NULL;
  }
}

/*! \brief Armazena o nome do usuário
 * \param entrada Objeto onde será armazenado o nome
 * \param event Objeto do tipo SDL_Event onde são armazenados os eventos ocorridos no jogo
 * \param font Fonte na qual será escrito nome
 * \param textColor Cor do texto */
void handle_stringInput(nom entrada, SDL_Event event, TTF_Font *font, SDL_Color textColor)
{
  /*Keep a copy of the current version of the string*/
  char *temp = calloc(15, sizeof(char));
  strcpy(temp, entrada->nome);
  if(event.type == SDL_KEYDOWN){ /*If a key was pressed*/
    if(strlen(entrada->nome) <= 15){ /*If the string less than maximum size*/
      if(event.key.keysym.unicode == (Uint16)' ') /*If the key is a space*/
        entrada->nome[entrada->indiceVetor++] = (char) event.key.keysym.unicode; /*Append the character*/
      else if((event.key.keysym.unicode >= (Uint16)'0') && (event.key.keysym.unicode <= (Uint16)'9')) /*If the key is a number*/
        entrada->nome[entrada->indiceVetor++] = (char) event.key.keysym.unicode; /*Append the character*/
      else if((event.key.keysym.unicode >= (Uint16)'A') && (event.key.keysym.unicode <= (Uint16)'Z')) /*If the key is a uppercase letter*/
        entrada->nome[entrada->indiceVetor++] = (char) event.key.keysym.unicode; /*Append the character*/
      else if((event.key.keysym.unicode >= (Uint16)'a') && (event.key.keysym.unicode <= (Uint16)'z')) /*If the key is a lowercase letter*/
        entrada->nome[entrada->indiceVetor++] = (char) event.key.keysym.unicode; /*Append the character*/
    }
    if((event.key.keysym.sym == SDLK_BACKSPACE) && (strlen(entrada->nome) != 0)) /*If backspace was pressed and the string isn't blank*/
      entrada->nome[--entrada->indiceVetor] = '\0'; /*Remove a character from the end */
    if(strcmp(entrada->nome, temp) != 0){
      if(entrada->texto != NULL)
        SDL_FreeSurface(entrada->texto);
      entrada->texto = TTF_RenderText_Solid(font, entrada->nome, textColor);
    }
  }
}

/*! \brief Aplica o nome do usuário no centro da tela
 * \param entrada Objeto com o nome do usuário
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo
 * \param screen Tela de jogo */
void show_centered(nom entrada, int SCREEN_WIDTH, int SCREEN_HEIGHT, SDL_Surface *screen)
{
  if(entrada->texto != NULL)
    apply_surface((SCREEN_WIDTH - entrada->texto->w) / 2, (SCREEN_HEIGHT - entrada->texto->h) / 2 + 30, entrada->texto, screen, NULL);
}
