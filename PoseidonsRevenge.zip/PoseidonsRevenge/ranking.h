/*! \file ranking.h
 * \brief Interface de ranking.c */

/*! \brief Tipo que será usado para representar um ranking */
typedef struct ranking *rank;
/*! \brief Estrutura para o tipo rank. Essa estrutura será usada para fazer a lista ligada do ranking */
struct ranking{
  /*! \brief String com o nome do jogador */
  char *nome;
  /*! \brief Pontuação de recorde */
  int pontuacao;
  /*! \brief Classificação do jogador */
  int posicao;
  /*! \brief Próxima célula do ranking */
  rank next;
};

void carregaBotaoRanking(SDL_Surface **vetorBotaoRanking);

char *converteInteiroString(int pontuacao);

void abreRanking();

void imagensRanking(SDL_Surface **posicao, SDL_Surface **nomes, SDL_Surface **pontuacao, TTF_Font *font, SDL_Color textColor);

int checaPontuacao(char *jogadorNome, int jogadorPontuacao);

void liberaRanking();
