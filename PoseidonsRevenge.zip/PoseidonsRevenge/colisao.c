/*! \file colisao.c
 * \brief Arquivo com as funções que tratam das colisões */
#include <stdio.h>
#include <math.h>
#include "colisao.h"

/*! \brief Calcula a distância entre dois pontos P1 e P2 
 * \param x1 X de P1
 * \param y1 Y de P1
 * \param x2 X de P2
 * \param y2 Y de P2
 * \return A distância entre P1 e P2 */
double distancia(int x1, int y1, int x2, int y2)
{
  return sqrt(pow(x2-x1,2) + pow(y2-y1,2));
}

/*! \brief Verifica de ocorreu colisão entre o círculo A e o círculo B
 * \param A Círculo A
 * \param B Círculo B
 * \return 1 caso tenha ocorrido colisão, 0 caso contrário */
int checaColisao(circ A, circ B)
{
  if(distancia(A->circuloX,A->circuloY,B->circuloX,B->circuloY) < (A->raio + B->raio))
    return TRUE;
  return FALSE;
}

/*! \brief Verifica se aumentou a distância entre o barco e um determinado alvo
 * \param barco Círculo do barco do jogador
 * \param alvo Círculo do alvo
 * \param deltaX Possível acréscimo na coordenada x do barco
 * \param deltaY Possível acréscimo na coordenada y do barco
 * \return 1 caso tenha aumentado a distância, 0 caso contrário */
int aumentouDistancia(circ barco, circ alvo, int deltaX, int deltaY)
{
  int distancia1, distancia2;
  distancia1 = distancia(barco->circuloX + deltaX, barco->circuloY + deltaY, alvo->circuloX, alvo->circuloY);
  distancia2 = distancia(barco->circuloX, barco->circuloY, alvo->circuloX, alvo->circuloY);
  if(distancia1 <= distancia2)
    return FALSE;
  return TRUE;
}

