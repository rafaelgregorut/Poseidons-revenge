/*! \file barco.c
 * \brief Arquivo com as funções relativas ao barco principal: carregamento de imagens, movimentação, e teclado*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "image.h"
#include "barco.h"

/*The dimensions of the boat*/
/*! \brief Largura do barco */
const int DOT_WIDTH = 70;
/*! \brief Altura do barco */
const int DOT_HEIGHT = 70;
int curvaDireita = FALSE, curvaEsquerda = FALSE, moveTras = FALSE, moveFrente = FALSE, moveBolsaDeVento = FALSE;

/*! \brief Função responsável pelo carregamento das imagens do barco principal 
 * \param barcoJogador Vetor do tipo SDL_Surface no qual serão armazenadas as figuras do barco do jogador */
void carregaVetorImagensBarcoJogador(SDL_Surface **barcoJogador)
{
  barcoJogador[0] = load_image("imagens/barcoJogador/barcoJogador1.png");
  barcoJogador[1] = load_image("imagens/barcoJogador/barcoJogador2.png");
  barcoJogador[2] = load_image("imagens/barcoJogador/barcoJogador3.png");
  barcoJogador[3] = load_image("imagens/barcoJogador/barcoJogador4.png");
  barcoJogador[4] = load_image("imagens/barcoJogador/barcoJogador5.png");
  barcoJogador[5] = load_image("imagens/barcoJogador/barcoJogador6.png");
  barcoJogador[6] = load_image("imagens/barcoJogador/barcoJogador7.png");
  barcoJogador[7] = load_image("imagens/barcoJogador/barcoJogador8.png");
  barcoJogador[8] = load_image("imagens/barcoJogador/barcoJogador9.png");
  barcoJogador[9] = load_image("imagens/barcoJogador/barcoJogador10.png");
  barcoJogador[10] = load_image("imagens/barcoJogador/barcoJogador11.png");
  barcoJogador[11] = load_image("imagens/barcoJogador/barcoJogador12.png");
  barcoJogador[12] = load_image("imagens/barcoJogador/barcoJogador13.png");
  barcoJogador[13] = load_image("imagens/barcoJogador/barcoJogador14.png");
  barcoJogador[14] = load_image("imagens/barcoJogador/barcoJogador15.png");
  barcoJogador[15] = load_image("imagens/barcoJogador/barcoJogador16.png");	
}

/*! \brief Função responsável pelo carregamento das imagens da barra inferior de vida 
 * \param barraVida Vetor do tipo SDL_Surface no qual serão armazenadas as figuras da barra de vida */
void carregaBarraVida(SDL_Surface **barraVida)
{
  barraVida[0] = load_image("imagens/barras/vida1.png");
  barraVida[1] = load_image("imagens/barras/vida2.png");
  barraVida[2] = load_image("imagens/barras/vida3.png");
  barraVida[3] = load_image("imagens/barras/vida4.png");
  barraVida[4] = load_image("imagens/barras/vida5.png");
  barraVida[5] = load_image("imagens/barras/vida6.png");
  barraVida[6] = load_image("imagens/barras/vida7.png");
  barraVida[7] = load_image("imagens/barras/vida8.png");
  barraVida[8] = load_image("imagens/barras/vida9.png");
  barraVida[9] = load_image("imagens/barras/vida10.png");
  barraVida[10] = load_image("imagens/barras/vida11.png");
  barraVida[11] = load_image("imagens/barras/vida12.png");
  barraVida[12] = load_image("imagens/barras/vida13.png");
  barraVida[13] = load_image("imagens/barras/vida14.png");
  barraVida[14] = load_image("imagens/barras/vida15.png");
  barraVida[15] = load_image("imagens/barras/vida16.png");	
  barraVida[16] = load_image("imagens/barras/vida17.png");
  barraVida[17] = load_image("imagens/barras/vida18.png");
  barraVida[18] = load_image("imagens/barras/vida19.png");
  barraVida[19] = load_image("imagens/barras/vida20.png");
  barraVida[20] = load_image("imagens/barras/vida21.png");
  barraVida[21] = load_image("imagens/barras/vida22.png");
  barraVida[22] = load_image("imagens/barras/vida23.png");
  barraVida[23] = load_image("imagens/barras/vida24.png");
  barraVida[24] = load_image("imagens/barras/vida25.png");
  barraVida[25] = load_image("imagens/barras/vida26.png");
  barraVida[26] = load_image("imagens/barras/vida27.png");
  barraVida[27] = load_image("imagens/barras/vida28.png");
  barraVida[28] = load_image("imagens/barras/vida29.png");
  barraVida[29] = load_image("imagens/barras/vida30.png");
  barraVida[30] = load_image("imagens/barras/vida31.png");
  barraVida[31] = load_image("imagens/barras/vida32.png");
  barraVida[32] = load_image("imagens/barras/vida33.png");
  barraVida[33] = load_image("imagens/barras/vida34.png");
  barraVida[34] = load_image("imagens/barras/vida35.png");
  barraVida[35] = load_image("imagens/barras/vida36.png");
  barraVida[36] = load_image("imagens/barras/vida37.png");
  barraVida[37] = load_image("imagens/barras/vida38.png");
  barraVida[38] = load_image("imagens/barras/vida39.png");
  barraVida[39] = load_image("imagens/barras/vida40.png");
  barraVida[40] = load_image("imagens/barras/vida41.png");
}

/*! \brief Função responsável pelo carregamento das imagens da barra inferior de vida dos inimigos 
 * \param barraVida Vetor do tipo SDL_Surface no qual serão armazenadas as figuras da barra de vida dos inimigos */
void carregaBarraVidaInimigo(SDL_Surface **barraVidaInimigo)
{
  barraVidaInimigo[0] = load_image("imagens/barras/vidaInimigo1.png");
  barraVidaInimigo[1] = load_image("imagens/barras/vidaInimigo2.png");
  barraVidaInimigo[2] = load_image("imagens/barras/vidaInimigo3.png");
  barraVidaInimigo[3] = load_image("imagens/barras/vidaInimigo4.png");
  barraVidaInimigo[4] = load_image("imagens/barras/vidaInimigo5.png");
  barraVidaInimigo[5] = load_image("imagens/barras/vidaInimigo6.png");
  barraVidaInimigo[6] = load_image("imagens/barras/vidaInimigo7.png");
  barraVidaInimigo[7] = load_image("imagens/barras/vidaInimigo8.png");
  barraVidaInimigo[8] = load_image("imagens/barras/vidaInimigo9.png");
  barraVidaInimigo[9] = load_image("imagens/barras/vidaInimigo10.png");
  barraVidaInimigo[10] = load_image("imagens/barras/vidaInimigo11.png");
  barraVidaInimigo[11] = load_image("imagens/barras/vidaInimigo12.png");
  barraVidaInimigo[12] = load_image("imagens/barras/vidaInimigo13.png");
  barraVidaInimigo[13] = load_image("imagens/barras/vidaInimigo14.png");
  barraVidaInimigo[14] = load_image("imagens/barras/vidaInimigo15.png");
  barraVidaInimigo[15] = load_image("imagens/barras/vidaInimigo16.png");	
  barraVidaInimigo[16] = load_image("imagens/barras/vidaInimigo17.png");
  barraVidaInimigo[17] = load_image("imagens/barras/vidaInimigo18.png");
  barraVidaInimigo[18] = load_image("imagens/barras/vidaInimigo19.png");
  barraVidaInimigo[19] = load_image("imagens/barras/vidaInimigo20.png");
  barraVidaInimigo[20] = load_image("imagens/barras/vidaInimigo21.png");
  barraVidaInimigo[21] = load_image("imagens/barras/vidaInimigo22.png");
  barraVidaInimigo[22] = load_image("imagens/barras/vidaInimigo23.png");
  barraVidaInimigo[23] = load_image("imagens/barras/vidaInimigo24.png");
  barraVidaInimigo[24] = load_image("imagens/barras/vidaInimigo25.png");
  barraVidaInimigo[25] = load_image("imagens/barras/vidaInimigo26.png");
  barraVidaInimigo[26] = load_image("imagens/barras/vidaInimigo27.png");
  barraVidaInimigo[27] = load_image("imagens/barras/vidaInimigo28.png");
  barraVidaInimigo[28] = load_image("imagens/barras/vidaInimigo29.png");
  barraVidaInimigo[29] = load_image("imagens/barras/vidaInimigo30.png");
  barraVidaInimigo[30] = load_image("imagens/barras/vidaInimigo31.png");
  barraVidaInimigo[31] = load_image("imagens/barras/vidaInimigo32.png");
  barraVidaInimigo[32] = load_image("imagens/barras/vidaInimigo33.png");
  barraVidaInimigo[33] = load_image("imagens/barras/vidaInimigo34.png");
  barraVidaInimigo[34] = load_image("imagens/barras/vidaInimigo35.png");
  barraVidaInimigo[35] = load_image("imagens/barras/vidaInimigo36.png");
  barraVidaInimigo[36] = load_image("imagens/barras/vidaInimigo37.png");
  barraVidaInimigo[37] = load_image("imagens/barras/vidaInimigo38.png");
  barraVidaInimigo[38] = load_image("imagens/barras/vidaInimigo39.png");
  barraVidaInimigo[39] = load_image("imagens/barras/vidaInimigo40.png");
  barraVidaInimigo[40] = load_image("imagens/barras/vidaInimigo41.png");
}

/*! \brief Função responsável pelo carregamento das imagens da barra inferior de magia 
 * \param barraVida Vetor do tipo SDL_Surface no qual serão armazenadas as figuras da barra de magia */
void carregaBarraMagia(SDL_Surface **barraMagia)
{
  barraMagia[0] = load_image("imagens/barras/magia1.png");
  barraMagia[1] = load_image("imagens/barras/magia2.png");
  barraMagia[2] = load_image("imagens/barras/magia3.png");
  barraMagia[3] = load_image("imagens/barras/magia4.png");
  barraMagia[4] = load_image("imagens/barras/magia5.png");
  barraMagia[5] = load_image("imagens/barras/magia6.png");
  barraMagia[6] = load_image("imagens/barras/magia7.png");
  barraMagia[7] = load_image("imagens/barras/magia8.png");
  barraMagia[8] = load_image("imagens/barras/magia9.png");
  barraMagia[9] = load_image("imagens/barras/magia10.png");
  barraMagia[10] = load_image("imagens/barras/magia11.png");
  barraMagia[11] = load_image("imagens/barras/magia12.png");
  barraMagia[12] = load_image("imagens/barras/magia13.png");
  barraMagia[13] = load_image("imagens/barras/magia14.png");
  barraMagia[14] = load_image("imagens/barras/magia15.png");
  barraMagia[15] = load_image("imagens/barras/magia16.png");	
  barraMagia[16] = load_image("imagens/barras/magia17.png");
  barraMagia[17] = load_image("imagens/barras/magia18.png");
  barraMagia[18] = load_image("imagens/barras/magia19.png");
  barraMagia[19] = load_image("imagens/barras/magia20.png");
  barraMagia[20] = load_image("imagens/barras/magia21.png");
  barraMagia[21] = load_image("imagens/barras/magia22.png");
  barraMagia[22] = load_image("imagens/barras/magia23.png");
  barraMagia[23] = load_image("imagens/barras/magia24.png");
  barraMagia[24] = load_image("imagens/barras/magia25.png");
  barraMagia[25] = load_image("imagens/barras/magia26.png");
  barraMagia[26] = load_image("imagens/barras/magia27.png");
  barraMagia[27] = load_image("imagens/barras/magia28.png");
  barraMagia[28] = load_image("imagens/barras/magia29.png");
  barraMagia[29] = load_image("imagens/barras/magia30.png");
  barraMagia[30] = load_image("imagens/barras/magia31.png");
  barraMagia[31] = load_image("imagens/barras/magia32.png");
  barraMagia[32] = load_image("imagens/barras/magia33.png");
  barraMagia[33] = load_image("imagens/barras/magia34.png");
  barraMagia[34] = load_image("imagens/barras/magia35.png");
  barraMagia[35] = load_image("imagens/barras/magia36.png");
  barraMagia[36] = load_image("imagens/barras/magia37.png");
  barraMagia[37] = load_image("imagens/barras/magia38.png");
  barraMagia[38] = load_image("imagens/barras/magia39.png");
  barraMagia[39] = load_image("imagens/barras/magia40.png");
  barraMagia[40] = load_image("imagens/barras/magia41.png");
}

/*! \brief Função responsável pelo carregamento das imagens da barra inferior de energia 
 * \param barraVida Vetor do tipo SDL_Surface no qual serão armazenadas as figuras da barra de energia */
void carregaBarraEnergia(SDL_Surface **barraEnergia)
{
  barraEnergia[0] = load_image("imagens/barras/energia1.png");
  barraEnergia[1] = load_image("imagens/barras/energia2.png");
  barraEnergia[2] = load_image("imagens/barras/energia3.png");
  barraEnergia[3] = load_image("imagens/barras/energia4.png");
  barraEnergia[4] = load_image("imagens/barras/energia5.png");
  barraEnergia[5] = load_image("imagens/barras/energia6.png");
  barraEnergia[6] = load_image("imagens/barras/energia7.png");
  barraEnergia[7] = load_image("imagens/barras/energia8.png");
  barraEnergia[8] = load_image("imagens/barras/energia9.png");
  barraEnergia[9] = load_image("imagens/barras/energia10.png");
  barraEnergia[10] = load_image("imagens/barras/energia11.png");
  barraEnergia[11] = load_image("imagens/barras/energia12.png");
  barraEnergia[12] = load_image("imagens/barras/energia13.png");
  barraEnergia[13] = load_image("imagens/barras/energia14.png");
  barraEnergia[14] = load_image("imagens/barras/energia15.png");
  barraEnergia[15] = load_image("imagens/barras/energia16.png");	
  barraEnergia[16] = load_image("imagens/barras/energia17.png");
  barraEnergia[17] = load_image("imagens/barras/energia18.png");
  barraEnergia[18] = load_image("imagens/barras/energia19.png");
  barraEnergia[19] = load_image("imagens/barras/energia20.png");
  barraEnergia[20] = load_image("imagens/barras/energia21.png");
  barraEnergia[21] = load_image("imagens/barras/energia22.png");
  barraEnergia[22] = load_image("imagens/barras/energia23.png");
  barraEnergia[23] = load_image("imagens/barras/energia24.png");
  barraEnergia[24] = load_image("imagens/barras/energia25.png");
  barraEnergia[25] = load_image("imagens/barras/energia26.png");
  barraEnergia[26] = load_image("imagens/barras/energia27.png");
  barraEnergia[27] = load_image("imagens/barras/energia28.png");
  barraEnergia[28] = load_image("imagens/barras/energia29.png");
  barraEnergia[29] = load_image("imagens/barras/energia30.png");
  barraEnergia[30] = load_image("imagens/barras/energia31.png");
  barraEnergia[31] = load_image("imagens/barras/energia32.png");
  barraEnergia[32] = load_image("imagens/barras/energia33.png");
  barraEnergia[33] = load_image("imagens/barras/energia34.png");
  barraEnergia[34] = load_image("imagens/barras/energia35.png");
  barraEnergia[35] = load_image("imagens/barras/energia36.png");
  barraEnergia[36] = load_image("imagens/barras/energia37.png");
  barraEnergia[37] = load_image("imagens/barras/energia38.png");
  barraEnergia[38] = load_image("imagens/barras/energia39.png");
  barraEnergia[39] = load_image("imagens/barras/energia40.png");
  barraEnergia[40] = load_image("imagens/barras/energia41.png");
}

/*! \brief Função que lida com os eventos do teclado.
 * \param dot É o barco do jogador
 * \param event Evento do tipo SDL_Event
 * \param flecha Lista ligada de ataques flechas
 * \param bolaDeFogo Lista ligada de ataques bolas de fogo
 * \param flechaFogo Lista ligada de ataques flechas de fogo
 * \param raio Lista ligada de ataques raios
 * \param aguia Lista liagada de ataques aguia*/
void handle_input(Dot dot, SDL_Event event, ataque flecha, ataque bolaDeFogo, ataque flechaFogo, ataque raio, ataque aguia)
{
  /*Se uma tecla foi pressionada*/
  if(event.type == SDL_KEYDOWN){
    switch(event.key.keysym.sym){
    case SDLK_UP: /*move o barco para frente*/
      if(dot->energia >= 0){
	dot->distanciaPercorrida += 5;
	dot->energia -= 5;
	moveFrente = TRUE;
      }
      break;
    case SDLK_DOWN: /*move o barco para tras*/
      if(dot->energia >= 0){
	dot->distanciaPercorrida -= 5;
	dot->energia -= 5;
	moveTras = TRUE;
      }
      break;
    case SDLK_LEFT: /*faz curva para a esquerda*/
      curvaEsquerda = TRUE;
      break;
    case SDLK_RIGHT:/*faz curva para a direita*/ 
      curvaDireita = TRUE;
      break; 
    case SDLK_d: /*move com a bolsa de ventos*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE){
	if(dot->ups[UP_BOLSAVENTOS] == TRUE){
	  if(dot->magia >= 5){
	    dot->distanciaPercorrida += 7;
	    dot->magia -= 5;
	    moveBolsaDeVento = TRUE;
	  }	
	}	
      }
      break;
    case SDLK_c: /*criar uma nova flecha.*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE)
	if(contaFlechas(flecha) <= 5)
	  novoAtaque(dot, flecha, 25, 25, 15, 300, 10);
      break;
    case SDLK_v: /*criar uma nova bola de fogo.*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE){
	if(dot->magia >= 10){
	  novoAtaque(dot, bolaDeFogo, 20, 20, 10, 500, 30);
	  dot->magia -= 10;
	}
      }
      break;
    case SDLK_f: /*criar uma nova flecha de fogo.*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE){
	if(dot->ups[UP_FLECHAFOGO] == TRUE){
	  if(dot->energia >= 10){
	    novoAtaque(dot, flechaFogo, 25, 25, 15, 300, 30);
	    dot->energia -= 10;
	  }
	}
      }
      break;
    case SDLK_b: /*criar um novo raio.*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE){
	if(dot->magia >= 50){
	  novoAtaque(dot, raio, 40, 40, 25, 700, 50);
	  dot->magia -= 50;
	}
      }
      break;
    case SDLK_g: /*criar um novo ataque aguia*/
      if(dot->fase >= FASE_1 && dot->fase != UPGRADE){
	if(dot->ups[UP_AGUIA] == TRUE){
	  if(aguia->next == NULL && dot->magia >= 100){
	    novoAtaque(dot, aguia, 150, 150, 35, 700, 100);
	    dot->magia -= 100;
	  }
	}
      }
      break;
    case SDLK_SPACE: /*levanta ou abaixa a vela do barco*/
      dot->parado = 1 - dot->parado;
      break;
    default : ;
    }
  }
  /*Se uma tecla foi solta*/
  else if(event.type == SDL_KEYUP){
    switch(event.key.keysym.sym){
    case SDLK_UP: /*para de se mover para frente*/
      if(moveFrente == TRUE){
	dot->distanciaPercorrida -= 5; 
	moveFrente = FALSE;
      }
      break;
    case SDLK_DOWN: /*para de se mover para tras*/
      if(moveTras == TRUE){
	dot->distanciaPercorrida += 5; 
	moveTras = FALSE;
      }
      break;
    case SDLK_LEFT: /*nao faz curva para a esquerda*/
      curvaEsquerda = FALSE;
      break;
    case SDLK_RIGHT: /*nao faz curva para a direita*/
      curvaDireita = FALSE;
      break;
    case SDLK_d: /*criar uma nova flecha.*/
      if(moveBolsaDeVento == TRUE){
	dot->distanciaPercorrida -= 7;
	moveBolsaDeVento = FALSE;
      }
      break;
    default : ;
    }
  }
}

/*! \brief Diz se o vento está favorável para uma determinada angulação do barco
 * \param dot O barco do jogador 
 * \return 1 se o vento está favorável, 0 caso contrário */
int ventoFavoravel(Dot dot)
{
  switch((int)dot->indiceVetor){
  case 0:
    return 1;
    break;
  case 1:
    return 1;
    break;
  case 2:
    return 1;
    break;
  case 3:
    return 1;
    break;
  case 13:
    return 1;
    break;
  case 14:
    return 1;
    break;
  case 15:
    return 1;
    break;
  default:
    return 0;
    break;
  }
}

/*! \brief Move o barco somente com a ação do vento
 * \param dot O barco do jogador
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo
 * \param cabecaMonstro Lista ligada de monstros da fase atual
 * \param ilhaCatapulta Ilha do cenário */
void moveVento(Dot dot, int SCREEN_WIDTH, int SCREEN_HEIGHT, monstro cabecaMonstro, Dot ilhaCatapulta)
{
  int distanciaComVento = 2;
  int deltaX, deltaY, novoX, novoY, colisaoMonstros, colisaoIlhaCatapulta = FALSE;
  colisaoMonstros = colisaoBarco(dot, cabecaMonstro);
  if(ilhaCatapulta != NULL)
    colisaoIlhaCatapulta = checaColisao(dot->circulo, ilhaCatapulta->circulo);
  if(dot->indiceVetor == 4 || dot->indiceVetor == 12)
    return;
  deltaX = distanciaComVento*cos(dot->angulo);
  deltaY = distanciaComVento*sin(dot->angulo);
  if(ventoFavoravel(dot)){
    novoX = dot->x + deltaX;
    /*atualizo a posicao do x*/
    if(novoX >= 0 && novoX < SCREEN_WIDTH - DOT_WIDTH &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, deltaX, 0))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, deltaX, 0))){
        dot->x = novoX;
        dot->circulo->circuloX += deltaX;
      }
    /*atualizo a posicao do y*/
    novoY = dot->y - deltaY;
    if(novoY >= 0 && novoY < SCREEN_HEIGHT - DOT_HEIGHT &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, 0, -1 * deltaY))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, 0, -1 * deltaY))){
        dot->y = novoY;
        dot->circulo->circuloY -= deltaY;
      }
  }
  else{
    novoX = dot->x - deltaX;
    /*atualizo a posicao do x*/
    if(novoX >= 0 && novoX < SCREEN_WIDTH - DOT_WIDTH &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, -1 * deltaX, 0))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, -1 * deltaX, 0))){
        dot->x = novoX;
        dot->circulo->circuloX -= deltaX;
      }
    /*atualizo a posicao do y*/
    novoY = dot->y + deltaY;
    if(novoY >= 0 && novoY < SCREEN_HEIGHT - DOT_HEIGHT &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, 0, deltaY))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, 0, deltaY))){
        dot->y = novoY;
        dot->circulo->circuloY += deltaY;
      }
  }
}

/*! \brief Move o barco com o pressionamento das setas direcionais
 * \param dot Barco do jogador
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo
 * \param event Evento do tipo SDL_Event
 * \param cabecaMonstro Cabeça da lista de monstros da fase atual 
 * \param ilhaCatapulta Ilha do cenário */
void moveBarco(Dot dot, int SCREEN_WIDTH, int SCREEN_HEIGHT, monstro cabecaMonstro, Dot ilhaCatapulta)
{
  int deltaX, deltaY, novoX, novoY, colisaoMonstros, colisaoIlhaCatapulta = FALSE;
  if(curvaEsquerda == TRUE && (dot->parado == FALSE || dot->distanciaPercorrida != 0)){
    dot->indiceVetor++;
    if(dot->indiceVetor > 15)
      dot->indiceVetor = 0;
    dot->angulo = dot->indiceVetor*22.5*3.141592654/180;
  }
  if(curvaDireita == TRUE && (dot->parado == FALSE || dot->distanciaPercorrida != 0)){
    dot->indiceVetor--;
    if(dot->indiceVetor < 0)
      dot->indiceVetor = 15;
    dot->angulo = dot->indiceVetor*22.5*3.141592654/180;	
  }
  colisaoMonstros = colisaoBarco(dot, cabecaMonstro);
  if(ilhaCatapulta != NULL)
    colisaoIlhaCatapulta = checaColisao(dot->circulo, ilhaCatapulta->circulo);
  if(dot->distanciaPercorrida != 0){
    deltaX = dot->distanciaPercorrida*cos(dot->angulo);
    deltaY = dot->distanciaPercorrida*sin(dot->angulo);
    novoX = dot->x + deltaX;
    /*atualizo a posicao do x*/
    if(novoX >= 0 && novoX < SCREEN_WIDTH - DOT_WIDTH &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, deltaX, 0))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, deltaX, 0))){
        dot->x = novoX;
        dot->circulo->circuloX += deltaX;
      }
    /*atualizo a posicao do y*/
    novoY = dot->y - deltaY;
    if(novoY >= 0 && novoY < SCREEN_HEIGHT - DOT_HEIGHT &&
       (colisaoIlhaCatapulta == FALSE || (colisaoIlhaCatapulta && aumentouDistancia(dot->circulo, ilhaCatapulta->circulo, deltaX, 0))))
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(dot->circulo, cabecaMonstro, 0, -1 * deltaY))){
        dot->y = novoY;
        dot->circulo->circuloY -= deltaY;
      }
  }
}
