/*! \file image.h
 * \brief Interface de image.c */

SDL_Surface *load_image(char *filename);

void apply_surface(int x, int y, SDL_Surface* source, SDL_Surface* destination, SDL_Rect* clip);
