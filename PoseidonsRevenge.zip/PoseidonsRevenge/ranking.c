/*! \file ranking.c 
 * \brief Arquivo com as funções referentes ao ranking de recordes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "image.h"
#include "ranking.h"

/*! \brief Cabeça da lista liagada dos nomes e pontuações presentes no ranking */
rank cabecaRanking;
/*! \brief Variável auxiliar para percorrer a lista de ranking */
rank apontaRanking;

/*! \brief Carrega as imagens do botão de ranking
 * \param vetorBotaoRanking Vetor do tipo SDL_Surface onde serão armazenadas as imagens do botão de ranking */
void carregaBotaoRanking(SDL_Surface **vetorBotaoRanking)
{
  vetorBotaoRanking[0] = load_image("imagens/botoes/botaoRanking1.png");
  vetorBotaoRanking[1] = load_image("imagens/botoes/botaoRanking2.png");
}

/*! \brief Converte um inteiro para string. Usado na pontuação. 
 * \param pontuacao A pontuação que se deseja converter 
 * \return A string com a pontuação */
char *converteInteiroString(int pontuacao)
{
  char *pontos;
  int tamanhoInteiro, potencia;
  pontos = calloc(5, sizeof(char));
  for(tamanhoInteiro = 0, potencia = 10; (pontuacao / potencia) > 0; tamanhoInteiro++, potencia *= 10);
  pontos[tamanhoInteiro + 1] = '\0';
  for(; tamanhoInteiro >= 0; tamanhoInteiro--){
    pontos[tamanhoInteiro] = (pontuacao % 10) + 48;
    pontuacao /= 10;
  }
  return pontos;
}

/*! \brief Inicializa um novo ranking */
void initRanking()
{
  cabecaRanking = malloc(sizeof *cabecaRanking);
  cabecaRanking->nome = NULL;
  cabecaRanking->pontuacao = 0;
  cabecaRanking->posicao = 0;
  cabecaRanking->next = NULL;
  apontaRanking = cabecaRanking;
}

/*! \brief Abre o arquivo de ranking (ranking.txt) */
void abreRanking()
{
  int i;
  char letra;
  FILE *arquivo;
  initRanking();
  arquivo = fopen("ranking.txt", "r");
  letra = fgetc(arquivo);
  while(letra != EOF){
    apontaRanking = (apontaRanking->next = malloc(sizeof *apontaRanking));
    apontaRanking->nome = calloc(15, sizeof(char));
    apontaRanking->pontuacao = 0;
    apontaRanking->posicao = 0;
    apontaRanking->next = NULL;
    while(letra != ' '){
      apontaRanking->posicao = (apontaRanking->posicao * 10) + (letra - 48);
      letra = fgetc(arquivo);
    }
    letra = fgetc(arquivo);
    if(letra == '_'){
        apontaRanking->pontuacao = 0;
        for(i = 0; i < 15; i++)
          apontaRanking->nome[i] = '.';
        letra = fgetc(arquivo);
        letra = fgetc(arquivo);
    }
    else{
      i = 0;
      while(letra != ' '){
        apontaRanking->nome[i++] = letra;
        letra = fgetc(arquivo);
      }
      letra = fgetc(arquivo);
      while(letra != 10){
        apontaRanking->pontuacao = (apontaRanking->pontuacao * 10) + (letra - 48);
        letra = fgetc(arquivo);
      }
      letra = fgetc(arquivo);
    }
  }
  fclose(arquivo);
}

/*! \brief Captura os dados do ranking.txt e transforma-os em superfícies para o SDL 
 * \param posicao Superficie onde será escrita a posição do recorde 
 * \param nomes Superfície onde será escrito nome do jogador que bateu um recorde 
 * \param pontuacao Surpefície onde será escrita a pontuação de quebra de recorde 
 * \param font Fonte com a qual será escrito novo recorde 
 * \param textColor Cor do texto */
void imagensRanking(SDL_Surface **posicao, SDL_Surface **nomes, SDL_Surface **pontuacao, TTF_Font *font, SDL_Color textColor)
{
  int i;
  for(i = 0, apontaRanking = cabecaRanking->next; apontaRanking; i++, apontaRanking = apontaRanking->next){
    posicao[i] = TTF_RenderText_Solid(font, converteInteiroString(apontaRanking->posicao), textColor);
    nomes[i] = TTF_RenderText_Solid(font, apontaRanking->nome, textColor);
    pontuacao[i] = TTF_RenderText_Solid(font, converteInteiroString(apontaRanking->pontuacao), textColor);
  }
}

/*! \brief Verifica se uma nova pontuação quebrou um recorde 
 * \param jogadorNome Nome do jogador
 * \param jogadorPontuacao Pontuação do jogador 
 * \return 1 caso tenha quebrado um recorde, 0 caso contrário */
int checaPontuacao(char *jogadorNome, int jogadorPontuacao)
{
  int i;
  rank novo, apontaUltimo;
  for(apontaRanking = cabecaRanking; apontaRanking->next; apontaRanking = apontaRanking->next)
    if(jogadorPontuacao > apontaRanking->next->pontuacao)
      break;
  if(apontaRanking->next != NULL){
    novo = malloc(sizeof *novo);
    novo->pontuacao = jogadorPontuacao;
    novo->nome = calloc(15, sizeof (char));
    for(i = 0; i < 15; i++)
      novo->nome[i] = jogadorNome[i];
    novo->posicao = apontaRanking->next->posicao;
    novo->next = apontaRanking->next;
    apontaRanking->next = novo;
    apontaRanking = novo->next;
    apontaUltimo = novo;
    while(apontaRanking->next){
      apontaRanking->posicao = apontaRanking->next->posicao;
      apontaRanking = apontaRanking->next;
      apontaUltimo = apontaUltimo->next;
    }
    apontaUltimo->next = NULL;
    free(apontaRanking->nome);
    free(apontaRanking);
    return 1;
  }
  return 0;
}

/*! \brief Libera um ranking */
void liberaRanking()
{
  FILE *arquivo;
  arquivo = fopen("ranking.txt", "w");
  for(apontaRanking = cabecaRanking; apontaRanking; apontaRanking = cabecaRanking){
    cabecaRanking = cabecaRanking->next;
    if(apontaRanking->nome){
      fprintf(arquivo, "%d ", apontaRanking->posicao);
      if(apontaRanking->nome[0] == '.')
        fprintf(arquivo, "_\n");
      else
        fprintf(arquivo, "%s %d\n", apontaRanking->nome, apontaRanking->pontuacao);
      free(apontaRanking->nome);
    }
    free(apontaRanking);
  }
  fclose(arquivo);
}
