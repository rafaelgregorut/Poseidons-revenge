/*! \file harpia.c
 * \brief Arquivo com as funções das imagens das harpias e com sua movimentação. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "image.h"
#include "monstro.h"

#define SOBE 0
#define DESCE 1
#define ESQUERDA 2
#define DIREITA 3

/*! \brief Delimita a área de atuacao das harpias*/
#define BORDA_SUP 45
/*! \brief Delimita a área de atuacao das harpias*/
#define BORDA_INF 280
/*! \brief Delimita a área de atuacao das harpias*/
#define BORDA_DIR 750
/*! \brief Delimita a área de atuacao das harpias*/
#define BORDA_ESQ 400

/*! \brief Função responsável pelo carregamento das imagens das harpias
 * \param vetorHarpia Vetor do tipo SDL_Surface que armazena as figuras das harpias */
void carregaVetorImagensHarpia(SDL_Surface **vetorHarpia)
{
  vetorHarpia[0] = load_image("imagens/monstros/harpia1.png");
  vetorHarpia[1] = load_image("imagens/monstros/harpia2.png");
}

/*! \brief Move uma hapia de maneira aleatória
 * \param harpia Objeto que representa uma harpia
 * \param SCREEN_WIDHT Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveHarpia(monstro harpia, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{
  /*int tempo = get_ticks(fps);*/
  int mudaSentido;
  int distancia = 5;/*essa distancia pode ser tanto no x qnto no y*/
  if(harpia->sentidoMov == SOBE){
    harpia->objMonstro->y += distancia*(-1);
    if(harpia->objMonstro->y < BORDA_SUP)
      harpia->objMonstro->y = BORDA_SUP;
  }
  else if(harpia->sentidoMov == DESCE){
    harpia->objMonstro->y += distancia;
    if(harpia->objMonstro->y > BORDA_INF)
      harpia->objMonstro->y = BORDA_INF;
  }
  else if(harpia->sentidoMov == ESQUERDA){
    harpia->objMonstro->x += distancia*(-1);
    if(harpia->objMonstro->x < BORDA_ESQ)
      harpia->objMonstro->x = BORDA_ESQ;
  }
  else if(harpia->sentidoMov == DIREITA){
    harpia->objMonstro->x += distancia;
    if(harpia->objMonstro->x > BORDA_DIR)
      harpia->objMonstro->x = BORDA_DIR;
  }
  mudaSentido = rand()%10;
  if(mudaSentido == 0)
    harpia->sentidoMov = rand()%4;
  harpia->objMonstro->circulo->circuloX = harpia->objMonstro->x + (harpia->objMonstro->largura / 2);
  harpia->objMonstro->circulo->circuloY = harpia->objMonstro->y + (harpia->objMonstro->altura / 2);
}
