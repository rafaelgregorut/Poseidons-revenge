/*! \file dot.c
 * \brief Arquivo que lida com o tipo dot, o qual é usado para representar o barco do jogador, a ilha, além de ser parte do tipo monstro. */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "dot.h"
#include "image.h"

/*! \brief Inicializa um dot
 * \param x A coordenada x do novo dot
 * \param y A coordenada y do novo dot
 * \param width A largura da imagem do novo dot
 * \param height A altura da imagem do novo dot
 * \param life O valor da vida do novo dot
 * \param stop Indica se o novo dot está parado ou não
 * \param angle É o ângulo do novo dot. Corresponde ao número da imagem atual do dot.
 * \return Retorna o novo dot */
Dot initDot(int x, int y, int width, int height, int life, int stop, float angle)
{
  Dot dot;
  int i;
  dot = malloc(sizeof *dot);
  dot->x = x;
  dot->y = y;
  dot->largura = width;
  dot->altura = height;
  dot->distanciaPercorrida = 0;
  dot->vida = life;
  dot->energia = 0; /*Só o barco precisará desse inteiro.*/ 
  dot->magia = 0; /*Só o barco precisará desse inteiro.*/
  dot->pontos = 0; /*Só o barco precisará desse inteiro.*/
  dot->parado = stop;
  dot->angulo = angle;
  dot->indiceVetor = 0.0;
  dot->circulo = malloc(sizeof *dot->circulo);
  dot->circulo->circuloX = x + (width / 2);
  dot->circulo->circuloY = y + (height / 2);
  dot->circulo->raio = 1.0 * height / 2;
  dot->fase = 0;
  dot->musicaTocando = 0;
  for(i = 0; i < 6; i++)
    dot->ups[i] = 0;
  return dot;
}

/*! \brief Libera um dot
 * \param libera O dot que deve ser liberado */
void liberaDot(Dot libera)
{
  if(libera){
    if(libera->circulo)
      free(libera->circulo);
    libera->circulo = NULL;
    free(libera);
    libera = NULL;
  }
}

/*! \brief Aplica o dot, no background e na screen*/
void show(Dot dot, SDL_Surface **imageDot, SDL_Surface *background, SDL_Surface *screen)
{
  apply_surface(0, 0, background, screen, NULL);
  apply_surface(dot->x, dot->y, imageDot[(int)dot->indiceVetor], screen, NULL);
}
