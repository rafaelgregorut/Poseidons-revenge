/*! \file music.h
 * \brief Interface de music.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"

int carregaVetorMusica(Mix_Music **music);

int PlayMusic(Mix_Music **music, int MusicNumber);

void PauseMusic();

void StopMusic();
