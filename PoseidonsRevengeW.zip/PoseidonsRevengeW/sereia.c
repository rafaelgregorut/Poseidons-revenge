/*! \file sereia.c
 * \brief Arquivo com a função de carregamento de imagens da sereia */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "image.h"
#include "monstro.h"

/*! \brief Função responsável pelo carregamento da imagem da sereia
 * \param vetorSereia Vetor do tipo SDL_Surface onde será armazenada a imagem da sereia */
void initSereia(SDL_Surface **vetorSereia)
{
  vetorSereia[0] = load_image("imagens/monstros/sereia1.png");
}

/*! \brief Inicializa uma ilha das sereias
 * \param x Coordenada x da ilha
 * \param y Coordenada y da ilha
 * \param largura Largura da imagem daa ilha
 * \param altura Altura da imagem da ilha
 * \return A nova ilha inicializada */
Dot initIlhaSereia(int x, int y, int largura, int altura, int raio)
{
  Dot ilhaSereia;
  ilhaSereia = initDot(x, y, largura, altura, 0, TRUE, 0.0);
  ilhaSereia->circulo->raio = raio;
  return ilhaSereia;
}

/*! \brief Verifica se o barco está na área de atração das sereias
 * \param atracao Objeto representando as sereias
 * \param barco Barco do jogador
 * \param raioAtracao Raio da área de atração
 * \return 1 caso o barco está dentro da área de atração, 0 caso contrário */
int estaNaAreaAtracao(Dot atracao, Dot barco, double raioAtracao)
{
  int deltaX = atracao->x - barco->x;
  int deltaY = atracao->y - barco->y;
  double distancia = sqrt(deltaX*deltaX + deltaY*deltaY);
  if(distancia <= raioAtracao && distancia >= atracao->altura)
    return 1;
  else
    return 0;
}

/*! \brief Move o barco do jogador na área de atração das sereias
 * \param sereia Objeto representando as sereias
 * \param barco Barco do jogador
 * \param raioAtracao Raio de atração das sereias
 * \param distanciaAtracao Distância que o barco percorre na área de atração das sereias 
 * \param cabecaMonstro Cabeça da lista ligada de monstros da fase corrente */
void moveBarcoSereia(Dot sereia, Dot barco, double raioAtracao, double distanciaAtracao, monstro cabecaMonstro)
{
  int colisaoMonstros, deltaX, deltaY, distanciaX, distanciaY;
  double angArrasto;
  colisaoMonstros = colisaoBarco(barco, cabecaMonstro);
  deltaX = barco->distanciaPercorrida * cos(barco->angulo);
  deltaY = barco->distanciaPercorrida * sin(barco->angulo);
  
  if(barco->circulo->circuloX != sereia->circulo->circuloX && barco->circulo->circuloY != sereia->circulo->circuloY){
    if(estaNaAreaAtracao(sereia, barco, raioAtracao) && barco->circulo->circuloX < sereia->circulo->circuloX){
      barco->energia -= 1;
      distanciaX = barco->circulo->circuloX - sereia->circulo->circuloX;
      distanciaY = barco->circulo->circuloY - sereia->circulo->circuloY;
      angArrasto = atan(((double) distanciaY) / ((double) distanciaX));
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(barco->circulo,cabecaMonstro,deltaX,deltaY))){
	barco->x += (int)(distanciaAtracao * cos(angArrasto));
	barco->y += (int)(distanciaAtracao * sin(angArrasto));
	barco->circulo->circuloX = barco->x + (barco->largura)/2;
	barco->circulo->circuloY = barco->y + (barco->altura)/2;
      }
    }
    else if(estaNaAreaAtracao(sereia, barco, raioAtracao) && barco->circulo->circuloX > sereia->circulo->circuloX){
      barco->energia -= 1;
      distanciaX = barco->circulo->circuloX - sereia->circulo->circuloX;
      distanciaY = barco->circulo->circuloY - sereia->circulo->circuloY;
      angArrasto = atan(((double) distanciaY) / ((double) distanciaX));
      if(colisaoMonstros == FALSE || (colisaoMonstros && aumentouDistanciaMonstro(barco->circulo,cabecaMonstro,deltaX,deltaY))){
	barco->x -= (int)(distanciaAtracao * cos(angArrasto));
	barco->y -= (int)(distanciaAtracao * sin(angArrasto));
	barco->circulo->circuloX = barco->x + (barco->largura)/2;
	barco->circulo->circuloY = barco->y + (barco->altura)/2;
      }
    }
  }
  /*casos em que barco->circulo->circuloX == sereia->circulo->circuloX*/
  else if(estaNaAreaAtracao(sereia,barco, raioAtracao) && barco->circulo->circuloY > sereia->circulo->circuloY){
    barco->energia -= 1;
    barco->y -= distanciaAtracao;
    barco->circulo->circuloY -= distanciaAtracao;
  }
  else if(estaNaAreaAtracao(sereia,barco, raioAtracao) && barco->circulo->circuloY < sereia->circulo->circuloY){
    barco->energia -= 1;
    barco->y += distanciaAtracao;
    barco->circulo->circuloY += distanciaAtracao;
  }
  /*casos em que barco->circulo->circuloY == sereia->circulo->circuloY*/
  else if(estaNaAreaAtracao(sereia,barco, raioAtracao) && barco->circulo->circuloX > sereia->circulo->circuloX){
    barco->energia -= 1;
    barco->x -= distanciaAtracao;
    barco->circulo->circuloX -= distanciaAtracao;
  }
  else if(estaNaAreaAtracao(sereia,barco, raioAtracao) && barco->circulo->circuloX < sereia->circulo->circuloX){
    barco->energia -= 1;
    barco->x += distanciaAtracao;;
    barco->circulo->circuloX += distanciaAtracao;
  }
}
