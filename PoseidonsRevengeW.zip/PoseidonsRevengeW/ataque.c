/*! \file ataque.c
 * \brief Arquivo com funções relativas aos ataques do barco principal: inicialização, carregamento das imagens e movimentação dos ataques */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "image.h"
#include "ataque.h"

/*! \brief Inicializa uma lista ligada de ataques
 * \return A cabeça da lista de ataques */
/*Toda vez q apertar c, uma nova celula flecha eh adicionada a lista.*/
ataque initListaAtaque()
{
  ataque cabeca;
  cabeca = malloc(sizeof *cabeca);
  cabeca->initX = 0;
  cabeca->initY = 0;
  cabeca->dano = 0;
  cabeca->next = NULL;
  cabeca->ultimo = cabeca;
  return cabeca;
}

/*! \brief Adiciona uma nova célula de ataque no final da lista ligada
 * \param barco Trata-se do barco principal, do qual será obtida a posição inicial do ataque
 * \param cabeca É a cabeca da lista ligada onde será adicionado o novo ataque
 * \param width É a largura da imagem do novo ataque
 * \param height É a altura da imagem do novo ataque
 * \param velocidade Trata-se da velocidade do ataque
 * \param distanciaMaxima É a distância máxima que um ataque pode percorrer
 * \param dano É o dano que o ataque em questão pode causar em um inimigo */
void novoAtaque(Dot barco, ataque cabeca, int width, int height, int velocidade, int distanciaMaxima, int dano)
{
  int x, y;
  ataque celula;
  celula = malloc(sizeof *celula);            
  x = barco->x + (barco->largura - width) / 2;
  y = barco->y + (barco->altura - height) / 2;
  celula->objAtaque = initDot(x, y, width, height, 0, FALSE, barco->angulo);
  celula->objAtaque->distanciaPercorrida = velocidade;
  celula->objAtaque->indiceVetor = barco->indiceVetor;
  celula->initX = x;
  celula->initY = y;
  celula->distanciaMaxima = distanciaMaxima;
  celula->dano = dano;
  celula->next = NULL;
  cabeca->ultimo->next = celula;
  cabeca->ultimo = celula;
}

/*! \brief Função que libera um ataque
 * \param libera Ataque que deve ser liberado */
void liberaAtaque(ataque libera)
{
  if(libera){
    free(libera);
    libera = NULL;
  }
}

/*! \brief Função responsável pelo carregamento das imagens do ataque flecha
 * \param flecha Vetor do Tipo SDL_Surface no qual serão armazenadas as figuras das flechas */
void carregaVetorImagensFlecha(SDL_Surface **flecha)
{
  flecha[0] = load_image("imagens/ataques/flecha1.png");
  flecha[1] = load_image("imagens/ataques/flecha2.png");
  flecha[2] = load_image("imagens/ataques/flecha3.png");
  flecha[3] = load_image("imagens/ataques/flecha4.png");
  flecha[4] = load_image("imagens/ataques/flecha5.png");
  flecha[5] = load_image("imagens/ataques/flecha6.png");
  flecha[6] = load_image("imagens/ataques/flecha7.png");
  flecha[7] = load_image("imagens/ataques/flecha8.png");
  flecha[8] = load_image("imagens/ataques/flecha9.png");
  flecha[9] = load_image("imagens/ataques/flecha10.png");
  flecha[10] = load_image("imagens/ataques/flecha11.png");
  flecha[11] = load_image("imagens/ataques/flecha12.png");
  flecha[12] = load_image("imagens/ataques/flecha13.png");
  flecha[13] = load_image("imagens/ataques/flecha14.png");
  flecha[14] = load_image("imagens/ataques/flecha15.png");
  flecha[15] = load_image("imagens/ataques/flecha16.png");	
}

/*! \brief Função que conta o número de flechas em uma lista ligada
 * \param cabecaFlechas Lista ligada onde estão as flechas atacadas
 * \return A quantidade de flechas da lista */
int contaFlechas(ataque cabecaFlechas)
{
  int numeroFlechas;
  ataque flecha;
  for(numeroFlechas = 1, flecha = cabecaFlechas->next; flecha; flecha = flecha->next)
    numeroFlechas++;
  return numeroFlechas;
}

/*! \brief Função responsável pelo carregamento das imagens do ataque bola de fogo
 * \param bolaDeFogo Vetor do tipo SDL_Surface no qual serão armazenadas as figuras das bolas de fogo */
void carregaVetorImagensBolaDeFogo(SDL_Surface **bolaDeFogo)
{
  bolaDeFogo[0] = load_image("imagens/ataques/BolaDeFogo.png");
}

/*! \brief Função responsável pelo carregamento das imagens do ataque flecha de fogo
 * \param flechaFogo Vetor do tipo SDL_Surface no qual serão armazenadas as figuras das flechas de fogo */
void carregaVetorImagensFlechaFogo(SDL_Surface **flechaFogo)
{
  flechaFogo[0] = load_image("imagens/ataques/flechaFogo1.png");
  flechaFogo[1] = load_image("imagens/ataques/flechaFogo2.png");
  flechaFogo[2] = load_image("imagens/ataques/flechaFogo3.png");
  flechaFogo[3] = load_image("imagens/ataques/flechaFogo4.png");
  flechaFogo[4] = load_image("imagens/ataques/flechaFogo5.png");
  flechaFogo[5] = load_image("imagens/ataques/flechaFogo6.png");
  flechaFogo[6] = load_image("imagens/ataques/flechaFogo7.png");
  flechaFogo[7] = load_image("imagens/ataques/flechaFogo8.png");
  flechaFogo[8] = load_image("imagens/ataques/flechaFogo9.png");
  flechaFogo[9] = load_image("imagens/ataques/flechaFogo10.png");
  flechaFogo[10] = load_image("imagens/ataques/flechaFogo11.png");
  flechaFogo[11] = load_image("imagens/ataques/flechaFogo12.png");
  flechaFogo[12] = load_image("imagens/ataques/flechaFogo13.png");
  flechaFogo[13] = load_image("imagens/ataques/flechaFogo14.png");
  flechaFogo[14] = load_image("imagens/ataques/flechaFogo15.png");
  flechaFogo[15] = load_image("imagens/ataques/flechaFogo16.png");	
}

/*! \brief Função responsável pelo carregamento das imagens do ataque raio
 * \param raio Vetor do tipo SDL_Surface no qual serão armazenadas as figuras do raio */
void carregaVetorImagensRaio(SDL_Surface **raio)
{
  raio[0] = load_image("imagens/ataques/raio1.png");
  raio[1] = load_image("imagens/ataques/raio2.png");
  raio[2] = load_image("imagens/ataques/raio3.png");
  raio[3] = load_image("imagens/ataques/raio4.png");
  raio[4] = load_image("imagens/ataques/raio5.png");
  raio[5] = load_image("imagens/ataques/raio6.png");
  raio[6] = load_image("imagens/ataques/raio7.png");
  raio[7] = load_image("imagens/ataques/raio8.png");
}

/*! \brief Função reponsável pelo carregamento das imagens do ataque águia
 * \param aguia Vetor do tipo SDL_Surface no qual serão armazenadas as figuras da aguia */
void carregaVetorImagensAguia(SDL_Surface **aguia)
{
  aguia[0] = load_image("imagens/ataques/aguia1.png");
  aguia[1] = load_image("imagens/ataques/aguia2.png");
  aguia[2] = load_image("imagens/ataques/aguia3.png");
  aguia[3] = load_image("imagens/ataques/aguia4.png");
  aguia[4] = load_image("imagens/ataques/aguia5.png");
  aguia[5] = load_image("imagens/ataques/aguia6.png");
  aguia[6] = load_image("imagens/ataques/aguia7.png");
  aguia[7] = load_image("imagens/ataques/aguia8.png");
  aguia[8] = load_image("imagens/ataques/aguia9.png");
  aguia[9] = load_image("imagens/ataques/aguia10.png");
  aguia[10] = load_image("imagens/ataques/aguia11.png");
  aguia[11] = load_image("imagens/ataques/aguia12.png");
  aguia[12] = load_image("imagens/ataques/aguia13.png");
  aguia[13] = load_image("imagens/ataques/aguia14.png");
  aguia[14] = load_image("imagens/ataques/aguia15.png");
  aguia[15] = load_image("imagens/ataques/aguia16.png");	
}

/*! \brief Função que atualiza a posição de ataques que danificam o primeiro monstro em seu caminho.
 * \param cabeca Cabeça da lista ligada de ataques a serem atualizados
 * \param cabecaMonstro Cabeça da lista ligada de monstros da fase atual do fogo
 * \param barco Barco do jogador 
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveAtaqueUnico(ataque cabeca, monstro cabecaMonstro, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{ 
  int novoX, novoY, largura, altura, distanciaMaxima, dano;
  float deltaX, deltaY, deslocamentoX, deslocamentoY, distancia;
  ataque celula, morta;
  for(celula = cabeca; celula->next; celula = celula->next){
    deslocamentoX = celula->next->objAtaque->distanciaPercorrida * cos(celula->next->objAtaque->angulo);
    deslocamentoY = celula->next->objAtaque->distanciaPercorrida * sin(celula->next->objAtaque->angulo) * (-1);
    novoX = (int)(celula->next->objAtaque->x + deslocamentoX);
    novoY = (int)(celula->next->objAtaque->y + deslocamentoY);
    largura =  celula->next->objAtaque->largura;
    altura = celula->next->objAtaque->altura;
    if(novoX >= 0 && novoX <= SCREEN_WIDTH -largura && novoY >= 0 && novoY <= SCREEN_HEIGHT - altura){
      celula->next->objAtaque->x += (int)deslocamentoX;
      celula->next->objAtaque->circulo->circuloX += (int)deslocamentoX;
      celula->next->objAtaque->y += (int)deslocamentoY;
      celula->next->objAtaque->circulo->circuloY += (int)deslocamentoY;
      deltaX = (float)(celula->next->objAtaque->x - celula->next->initX);
      deltaY = (float)(celula->next->objAtaque->y - celula->next->initY);
      distancia = sqrt(deltaX*deltaX+deltaY*deltaY);
      distanciaMaxima = celula->next->distanciaMaxima;
      dano = celula->next->dano;
      if(distancia > distanciaMaxima || colisaoAtaqueUnico(celula->next->objAtaque, cabecaMonstro, dano, barco)){
        morta = celula->next;
        celula->next = celula->next->next;
        liberaAtaque(morta);
        if(celula->next == NULL){
          cabeca->ultimo = celula;
          break;
        }
      }
    }
    else{
      morta = celula->next;
      celula->next = celula->next->next;
      liberaAtaque(morta);
      if(celula->next == NULL){
        cabeca->ultimo = celula;
        break;
      }
    }
  }
}

/*! \brief Função que atualiza a posição de ataques que danificam todos os monstros presentes na sua área de ataque. É o caso do ataque águia.
 * \param cabeca Cabeça da lista ligada de ataques a serem atualizados
 * \param cabecaMonstro Cabeça da lista ligada de monstros da fase atual do fogo
 * \param barco Barco do jogador 
 * \param SCREEN_WIDTH Largura da tela de jogo
 * \param SCREEN_HEIGHT Altura da tela de jogo */
void moveAtaqueArea(ataque cabeca, monstro cabecaMonstro, Dot barco, int SCREEN_WIDTH, int SCREEN_HEIGHT)
{   
  int novoX, novoY, largura, altura;
  float deltaX, deltaY, deslocamentoX, deslocamentoY, distancia;
  ataque celula, morta;
  for(celula = cabeca; celula->next; celula = celula->next){
    deslocamentoX = celula->next->objAtaque->distanciaPercorrida * cos(celula->next->objAtaque->angulo);
    deslocamentoY = celula->next->objAtaque->distanciaPercorrida * sin(celula->next->objAtaque->angulo) * (-1);
    novoX = (int)(celula->next->objAtaque->x + deslocamentoX);
    novoY = (int)(celula->next->objAtaque->y + deslocamentoY);
    largura = celula->next->objAtaque->largura;
    altura = celula->next->objAtaque->altura;
    celula->next->objAtaque->x += deslocamentoX;
    celula->next->objAtaque->circulo->circuloX += deslocamentoX;
    celula->next->objAtaque->y += deslocamentoY;
    celula->next->objAtaque->circulo->circuloY += deslocamentoY;
    deltaX = (float)(celula->next->objAtaque->x - celula->next->initX);
    deltaY = (float)(celula->next->objAtaque->y - celula->next->initY);
    distancia = sqrt(deltaX*deltaX+deltaY*deltaY);
    colisaoAtaqueArea(celula->next->objAtaque, cabecaMonstro, celula->next->dano, barco);
    if(distancia > celula->next->distanciaMaxima || 
       novoX < 0 || novoX > SCREEN_WIDTH - largura || novoY < 0 || novoY > SCREEN_HEIGHT - altura){
      morta = celula->next;
      celula->next = celula->next->next;
      liberaAtaque(morta);
      if(celula->next == NULL){
	cabeca->ultimo = celula;
	break;
      }
    }
  }
}
