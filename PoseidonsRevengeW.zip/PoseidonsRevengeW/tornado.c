/*! \file tornado.c
 * \brief Arquivo com a função de carregamento de imagem do tornado */
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "image.h"
#include "monstro.h"
#include <math.h>

/*! \brief Função reponsável pelo carregamento da imagem do tornado
 * \param vetorTornado Vetor do tipo SDL_Surface onde será armazenada a imagem do tornado */
void carregaVetorImagensTornado(SDL_Surface **vetorTornado)
{
  vetorTornado[0] = load_image("imagens/monstros/tornado1.png");
}

/*! \brief Verifica se o barco está dentro de um tornado
 * \param tornado Objeto representando o tornado
 * \param barco Barco do jogador
 * \return 1 caso o barco esteja dentro do tornado, 0 caso contrário */
int estaNoTornado(Dot tornado, Dot barco)
{
  if((barco->circulo->circuloX >= tornado->x && barco->circulo->circuloX <= tornado->x + tornado->largura) && (barco->circulo->circuloY >= tornado->y && barco->circulo->circuloY <= tornado->y + tornado->altura)){
    return 1;
  }
  else
    return 0;
}

/*! \brief Váriavel ro das coordenadas polares do movimento do barco dentro do tornado */
double ro = 15.0;
/*! \brief Indica se o barco já estava dentro de um tornado */
int jaEstavaNoTornado = 0;
/*! \brief Váriavel teta das coordenadas polare do movimento do barco dentro do tornado */
double teta = 0.0;

/*! \brief Move o barco dentro do tornado
 * \param atracao Objeto representando o tornado
 * \param barco Barco do jofgador 
 * \param raio Raio do tornado
 * \cabecaMonstro Cabeça da lista de monstros da fase atual */
void moveBarcoTornado(Dot atracao, Dot barco, double raio, monstro cabecaMonstro)
{
  if(estaNoTornado(atracao,barco)){
    if(jaEstavaNoTornado == 0)
      teta = atan(((double)(barco->y - atracao->y))/((double)(barco->x - atracao->x)));
    if(jaEstavaNoTornado == 0)
      teta *= -1;
    else
      teta += 1;
    barco->x -= ro*cos(teta);
    barco->y -= ro*sin(teta);
  }
  barco->circulo->circuloX = barco->x + (barco->largura)/2;
  barco->circulo->circuloY = barco->y + (barco->altura)/2;
  jaEstavaNoTornado = 1;	
}

