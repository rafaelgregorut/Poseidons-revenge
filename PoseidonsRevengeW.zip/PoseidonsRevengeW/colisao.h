/*! \file colisao.h
 * \brief Interface de colisao.c com a definição do tipo circ */

#define TRUE 1
#define FALSE 0

/*! \brief Tipo que representa o círculo de cada personagem. Usado para detectar colisões */
typedef struct circulo *circ;
/*! \brief Estrutura do círculo */
struct circulo{
  /*! \brief Coordenada x do centro do circulo */
  int circuloX;
  /*! \brief Coordenada y do centro do circulo */
  int circuloY;
  /*! \brief Raio do circulo. Vale metade da altura da imagem do personagem */
  double raio;
};

double distancia(int x1, int y1, int x2, int y2);

int checaColisao(circ A, circ B);

int aumentouDistancia(circ barco, circ alvo, int deltaX, int deltaY);
